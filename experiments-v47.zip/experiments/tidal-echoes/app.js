import * as THREE from './vendor/three.module.js';
import { applySculptureFrame, worldVelocityToLocal } from './sculpture-frame.js?v=spatial-28';
import { createNearField } from './near-field.js?v=spatial-28';
import { createGalaxyWorld } from './galaxy-world.js?v=cosmic-40';
import { ClutchNavigation } from './clutch-navigation.js?v=idle-grip-34';
import { NavigationFeedback } from './navigation-feedback.js?v=idle-grip-34';
import { calibrationResumeHint } from './calibration-feedback.js?v=resume-27';
import { OrbitCastTransition } from './orbit-cast-transition.js?v=partial-29';
import { OrbitPractice } from './orbit-practice.js?v=practice-17';
import { TidalSlingshot } from './tidal-slingshot.js?v=tidal-11';
import { createTidalSlingshotVisuals } from './tidal-slingshot-visuals.js';
import { PointTravel } from './point-travel.js?v=travel-30';
import { CameraRestRecovery } from './camera-rest-recovery.js?v=rest-31';
import { CosmicFlight } from './cosmic-flight.js';
import { findThrowAim } from './palm-throw-aim.js?v=palm-37';
import { PalmSceneControl } from './palm-scene-control.js?v=conductor-44';
import { PalmCasting } from './palm-casting.js?v=handoff-23';
import { findPalmTarget } from './palm-targeting.js?v=palm-19';
import { classifyHandIntent } from './hand-intent.js?v=contact-26';
import { ConstellationResonance } from './constellation-resonance.js?v=guide-26';
import { ResonanceGuidance } from './resonance-guidance.js?v=guide-26';
import { GravityBridge } from './gravity-bridge.js?v=recovery-15';
import { StardustRecovery } from './stardust-recovery.js?v=recovery-15';
import { createStardustRecoveryVisuals } from './stardust-recovery-visuals.js?v=recovery-15';
import { createGravityBridgeVisuals } from './gravity-bridge-visuals.js?v=bridge-14';
import { SCALE_STATIONS, stationDistance, nextStation } from './scale-stations.js';
import { RenderBudget } from './render-budget.js?v=conductor-38';
import { createBlackHole } from './blackhole-v2.js?v=conductor-38';
import { createCinematicRenderer } from './cinematic-renderer.js?v=conductor-38';
import { PersistentSingularityEngine } from './persistent-singularity.js?v=supernova-41';
import { createSingularityVisuals } from './singularity-visuals.js?v=cosmic-40';
import { createSupernovaVisuals } from './supernova-visuals.js?v=supernova-41';
import { classifyHandPose, stabilizeHandPose } from './hand-pose.js?v=pinch-16';
import { PhotonGame } from './photon-game.js';
import { updateMusic, resetMusic, initDefaultMusic, getMusicRecordingStream } from './music.js?v=bgm-47';
import { createArtworkRecorder } from './artwork-recorder.js?v=tidal-46';
import { webcamState, stopCamera, setCameraMode, startPinchCalibration, cancelPinchCalibration, resetPinchCalibration } from './camera.js?v=conductor-44';

const $ = id => document.getElementById(id);
const canvas=$('art'),viewport=$('viewport'),MAX=120000;
let renderer;
try {renderer=new THREE.WebGLRenderer({canvas,antialias:false,alpha:false,powerPreference:'high-performance'});}
catch(error){$('gesture-label').textContent='此设备无法启动三维画面，请使用支持 WebGL 2 的浏览器';throw error;}
renderer.setClearColor(0x020408,1);
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
renderer.xr.enabled=true;renderer.xr.setReferenceSpaceType('local');
const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(43,1,.05,30000);
const universe=new THREE.Group(),sculpture=new THREE.Group();scene.add(universe);universe.add(sculpture);
const nearField=createNearField(universe);
applySculptureFrame(sculpture);
const galaxy=createGalaxyWorld(universe),navigation=new ClutchNavigation(),flight=new CosmicFlight();
const pointTravel=new PointTravel();
let pointTravelResult={phase:'ready',action:null,progress:0,targetId:null,ownerId:null,label:''};
const cameraRestRecovery=new CameraRestRecovery();
let cameraRestResult={phase:'idle',action:null,label:''},cameraRestNoticeUntil=0;
const navigationFeedback=new NavigationFeedback(),orbitCastTransition=new OrbitCastTransition();
const orbitPractice=new OrbitPractice(),orbitPresets=[.65,1,1.45];
let orbitSensitivity=1,practiceRenderKey='';
try{const stored=Number(localStorage.getItem('light-thief-orbit-sensitivity'));if(orbitPresets.includes(stored))orbitSensitivity=stored;}catch{}
const focus=new THREE.Vector3(),desiredFocus=new THREE.Vector3(),xrAnchor=new THREE.Vector3(),xrAnchorRotation=new THREE.Quaternion();
let interactionMode='studio',viewDistance=10.2,navResult={label:'拇食指轻捏转角 · 松手停住'},cameraSession=0,hadCamera=false,cameraControlEpoch=0;
const MIN_DISTANCE=6.4,MAX_DISTANCE=6000;
const pipeline=createCinematicRenderer(renderer),blackhole=createBlackHole(sculpture),game=new PhotonGame(MAX);
game.setCount(32000);
const magic=new PersistentSingularityEngine(9000),magicVisuals=createSingularityVisuals(sculpture,magic);
const supernova=createSupernovaVisuals(sculpture,magic,{maxParticles:16800});
const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
// Audio is background playback only; scene engines never receive live analysis.
const NEUTRAL_SCENE_MUSIC=Object.freeze({playing:false,energy:0,bass:0,beat:0,note:0,subdivision:0,bands:Object.freeze([]),onsets:Object.freeze([])});
const sling=new TidalSlingshot(),slingVisuals=createTidalSlingshotVisuals(sculpture,sling);
const bridge=new GravityBridge(720),bridgeVisuals=createGravityBridgeVisuals(sculpture,bridge);
const recovery=new StardustRecovery({count:12,goal:6}),recoveryVisuals=createStardustRecoveryVisuals(sculpture,recovery);
let recoveryEnabled=false;
const casting=new PalmCasting();
let cameraControlStyle='palm',palmAimName='',primaryHand='Right',interfaceHidden=false;
try{if(localStorage.getItem('light-thief-primary-hand')==='Left')primaryHand='Left';}catch{}
try{if(localStorage.getItem('light-thief-camera-controls')==='classic')cameraControlStyle='classic';}catch{}
const palmControl=new PalmSceneControl({dual:true,primaryHand,engine:magic,toPoint:palmScenePoint,toDelta:palmSceneDelta,adjustTarget:palmDepthAssist,toVelocity:palmSceneVelocity,
 onObserve:()=>{stopFlight();stopDemonstrations();navigation.reset();targetYaw=yaw;targetPitch=pitch;},
 onTravel:direction=>{const next=nextStation(viewDistance,direction,{sling:slingEnabled,flightTarget:flight.active?flight.target:null});startFlight(stationDistance(next.id,{sling:slingEnabled}),{keepPalm:true});},
 onNotice:message=>toast(message.startsWith('星光已投出')&&palmAimName?'向「'+palmAimName+'」送光 · 已辅助对齐深度':message)});
let palmState=palmControl.state;
const resonance=new ConstellationResonance(),resonanceGuide=new ResonanceGuidance(),resonanceVisuals=createTidalSlingshotVisuals(sculpture,resonance);
let resonanceEnabled=false;
let demoCast=null;
let slingEnabled=false,placementArmed=false,helpOpen=false,magicDemo=false;
let time=0,lastTime=0,paused=false,power=1,glow=1,demo=false,demoTime=0,imageTargets=null,imageColors=null,imageToken=0;
let targetYaw=0,yaw=0,targetPitch=.11,pitch=.11,distance=10.2,statsTime=0,statsFrames=0,lastMessage='',messageUntil=0;
let xrMode=null,placePending=false,qualityRatio=Math.min(devicePixelRatio,1.5),qualityCooldown=0;
const renderBudget=new RenderBudget(devicePixelRatio);
let renderQuality=renderBudget.state,lastHudUpdate=-Infinity,recordingSize=null;
const paletteColors={ice:['#586d8a','#bfd7ee','#f5faff'],solar:['#9b3814','#e29847','#fff0ca'],nebula:['#26376e','#7160bb','#ccecff'],aurora:['#146374','#65c4b6','#ebb2ce'],ember:['#713539','#d77966','#ede4db']};
const sizes=new Float32Array(MAX),tones=new Float32Array(MAX),displayColors=new Float32Array(MAX*3);
let seed=2791;function random(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
for(let i=0;i<MAX;i++){sizes[i]=.55+Math.pow(random(),4)*1.8;tones[i]=random();displayColors[i*3]=displayColors[i*3+1]=displayColors[i*3+2]=1;}
const geo=new THREE.BufferGeometry();
geo.setAttribute('position',new THREE.BufferAttribute(game.positions,3).setUsage(THREE.DynamicDrawUsage));
geo.setAttribute('aEnergy',new THREE.BufferAttribute(game.energies,1).setUsage(THREE.DynamicDrawUsage));
geo.setAttribute('aOwner',new THREE.BufferAttribute(new Float32Array(MAX),1).setUsage(THREE.DynamicDrawUsage));
geo.setAttribute('aSize',new THREE.BufferAttribute(sizes,1));geo.setAttribute('aTone',new THREE.BufferAttribute(tones,1));geo.setAttribute('color',new THREE.BufferAttribute(displayColors,3));geo.setDrawRange(0,game.count);
const uniforms={uTime:{value:0},uPixel:{value:qualityRatio},uPitch:{value:0},uBeat:{value:0},uTick:{value:0},uMusic:{value:0},uImage:{value:0},uGlow:{value:1},uC0:{value:new THREE.Color()},uC1:{value:new THREE.Color()},uC2:{value:new THREE.Color()}};
const particles=new THREE.Points(geo,new THREE.ShaderMaterial({uniforms,vertexColors:true,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
vertexShader:`attribute float aEnergy,aOwner,aSize,aTone;varying vec3 vColor;varying float vAlpha;uniform float uTime,uPixel,uPitch,uBeat,uTick,uMusic,uImage,uGlow;uniform vec3 uC0,uC1,uC2;
vec3 palette(float t){return t<.5?mix(uC0,uC1,t*2.):mix(uC1,uC2,(t-.5)*2.);}
void main(){float r=length(position);float hot=clamp((3.6-r)/2.8,0.,1.);float tint=clamp(hot*.65+aTone*.35,0.,1.);float localBeat=fract(aTone*17.7+uTick*.618);tint=mix(tint,fract(aTone*.55+uPitch*.32+uTick*.071),uMusic*.7);vec3 c=mix(palette(tint),mix(color,palette(tint),uMusic*.2),uImage);float held=step(-.5,aOwner);float release=step(1.5,aOwner);c=mix(c,vec3(.38,.75,1.),held*.6);c=mix(c,vec3(.8,.91,1.),release*.7);float energy=1.+aEnergy*1.8+uMusic*uBeat*localBeat;vColor=c*energy*uGlow*(.6+hot*.5+held*1.5)*(1.+uImage*1.8);vec4 mv=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*mv;gl_PointSize=clamp(aSize*uPixel*(17.+aEnergy*8.+held*10.+uImage*8.)/max(.2,-mv.z),1.7,20.);vAlpha=.6+held*.3;}`,
fragmentShader:`varying vec3 vColor;varying float vAlpha;void main(){vec2 uv=gl_PointCoord-.5;float d=dot(uv,uv);if(d>.25)discard;float core=exp(-d*32.);float halo=exp(-d*12.)*.14;gl_FragColor=vec4(vColor*(core+halo),vAlpha);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}` }));particles.frustumCulled=false;sculpture.add(particles);
const TRAILS=4200,trailPos=new Float32Array(TRAILS*6),trailColors=new Float32Array(TRAILS*6),trailGeo=new THREE.BufferGeometry();
trailGeo.setAttribute('position',new THREE.BufferAttribute(trailPos,3).setUsage(THREE.DynamicDrawUsage));trailGeo.setAttribute('color',new THREE.BufferAttribute(trailColors,3).setUsage(THREE.DynamicDrawUsage));
const trails=new THREE.LineSegments(trailGeo,new THREE.LineBasicMaterial({vertexColors:true,transparent:true,opacity:.32,blending:THREE.AdditiveBlending,depthWrite:false}));trails.frustumCulled=false;sculpture.add(trails);
// The local black hole is part of the same spatial scene as the spiral arms.
// A small physical light seed is the entry point, not another on-screen menu.
const lightSeed=new THREE.Mesh(new THREE.IcosahedronGeometry(.085,1),new THREE.MeshBasicMaterial({color:new THREE.Color(2.1,2.5,3),toneMapped:false}));
lightSeed.position.set(3.45,1.45,2.65);sculpture.add(lightSeed);
let planetHint='';
function planetTargetsLocal(){
 return (galaxy.interactionTargets||[]).filter(t=>t.active).map(t=>{
  const p=sculpture.worldToLocal(universe.localToWorld(t.position.clone()));
  return{id:t.id,name:t.name,kind:t.kind,x:p.x,y:p.y,z:p.z,radius:t.radius};
 });
}
function universePoint(point){const p=universe.worldToLocal(sculpture.localToWorld(new THREE.Vector3(point.x,point.y,point.z)));return{...point,x:p.x,y:p.y,z:p.z};}
function transferPlanetLight(){
 let accepted=0;
 for(const transfer of galaxy.energyTransfers||[])accepted+=magic.absorbPlanetLight(transfer.wellId,transfer.amount);
 return accepted;
}
function aimPlanet(screen){
 const cursor=palmCursorPoint(screen);let found=null,best=Infinity;
 for(const target of planetTargetsLocal()){
  const p=sculpture.localToWorld(new THREE.Vector3(target.x,target.y,target.z));
  const radius=target.radius*viewport.clientHeight/(2*Math.tan(camera.fov*Math.PI/360)*camera.position.distanceTo(p));
  p.project(camera);const d=Math.hypot((p.x-cursor.x)*viewport.clientWidth*.5,(p.y-cursor.y)*viewport.clientHeight*.5);
  if(p.z>-1&&p.z<1&&d<Math.max(42,radius+25)&&d<best){found=target;best=d;}
 }
 return found;
}
const markerNodes=galaxy.landmarks.map(mark=>{const node=document.createElement('span');node.className='cosmic-label '+mark.kind;node.textContent=mark.name;$('cosmic-labels').append(node);return{...mark,node};});
const slingMarkers=[...sling.targets.map(target=>({target,handle:false})),{handle:true}].map(mark=>{const node=document.createElement('span');node.className='sling-label'+(mark.handle?' tail-label':'');node.hidden=true;$('cosmic-labels').append(node);return{...mark,node};});
const resonanceMarkers=resonance.targets.map(target=>{const node=document.createElement('span');node.className='sling-label';node.hidden=true;$('cosmic-labels').append(node);return{target,node};});
const constellationGeometry=new THREE.BufferGeometry().setFromPoints(resonance.targets.map(t=>new THREE.Vector3(t.x,t.y,t.z)).concat([new THREE.Vector3(resonance.targets[0].x,resonance.targets[0].y,resonance.targets[0].z)]));
const constellation=new THREE.Line(constellationGeometry,new THREE.LineBasicMaterial({color:0xc5e7ff,transparent:true,opacity:.24,depthWrite:false}));constellation.visible=false;sculpture.add(constellation);
const projected=new THREE.Vector3();
function smoothRange(value,lo,hi){const t=THREE.MathUtils.clamp((value-lo)/(hi-lo),0,1);return t*t*(3-2*t);}
function setDistance(value){distance=THREE.MathUtils.clamp(value,MIN_DISTANCE,MAX_DISTANCE);$('cosmic-zoom').value=Math.round(Math.log(distance/MIN_DISTANCE)/Math.log(MAX_DISTANCE/MIN_DISTANCE)*1000);}
function stopFlight(){flight.stop(viewDistance);setDistance(viewDistance);}
function cancelStudioInput({keepPalm=false}={}){
 if(!keepPalm){palmControl.cancel();palmState=palmControl.state;}
 cameraRestRecovery.cancel();cameraRestResult={phase:'idle',action:null,label:''};cameraRestNoticeUntil=0;
 pointTravelResult=pointTravel.update([],performance.now(),{enabled:false});
 magic.releaseGrabs({preserveSummonOwner:keepPalm?palmControl.owner:null});sling.cancelGrab();navigation.reset();orbitCastTransition.reset();casting.update([],0,{enabled:false});demoCast=null;
 for(const route of routes.values())route.kind='ignore';
 targetYaw=yaw;targetPitch=pitch;
}
function startFlight(destination,{keepPalm=false}={}){if(webcamState.calibration?.active)cancelPinchCalibration();cancelStudioInput({keepPalm});flight.start(viewDistance,destination);demo=false;}
function stopDemonstrations(){magicDemo=false;demo=false;$('demo').textContent='观看漫游演示';}
function setMode(mode){
 setInteractionHelp(false);
 interactionMode=mode==='play'?'play':'studio';setCameraMode(interactionMode,{palm:cameraControlStyle==='palm'});cancelStudioInput();stopFlight();stopDemonstrations();placementArmed=false;
 document.body.classList.toggle('magic',interactionMode==='studio');
 $('magic-dock').hidden=interactionMode!=='studio';$('zoom-rail').hidden=interactionMode!=='studio';document.querySelector('.game-dock').hidden=interactionMode!=='play';
 const steps=interactionMode==='studio'&&cameraControlStyle==='palm'?[['主手张掌 / 握拳','创造托举 / 持续推进'],['副手挥动 / 握拳','余势旋转 / 持续拉远'],['双手同时握拳','超新星爆发 · 张开取消']]:interactionMode==='studio'?[['拇食指捏合','转角 · 松开停住'],['拇中指捏合','创造 · 张掌托举'],['完整握拳','捏爆所有奇点']]:[['移动手掌','牵引星尘'],['捏合指尖','聚集光粒子'],['挥动后松开','释放 · 逃逸得分']];
 document.querySelector('.gesture-guide').innerHTML=steps.map((s,i)=>'<div><b>0'+(i+1)+'</b><span>'+s[0]+'<small>'+s[1]+'</small></span></div>').join('');
 game.reset();lastMessage='';$('move-name').textContent='';
 if(interactionMode==='play'){document.querySelector('.scene-caption>span').textContent='01 — 事件视界';document.querySelector('.scene-caption p').textContent='光抵达你的掌心，或坠入永夜。';resetView();viewDistance=distance;focus.set(0,0,0);yaw=targetYaw;pitch=targetPitch;}
}
function enterMagic(){if(imageTargets)clearImage();setMode('studio');setPanel(false);}
function seedWell(){
 if(magic.wells.some(w=>w.active))return;
 magic.update(.016,[{id:'starter',x:2.5,y:.4,z:2.8,pinching:true,immediate:true}],{});
 magic.update(.016,[{id:'starter',x:2.5,y:.4,z:2.8,pinching:false}],{});
}
function enterSling(){
 enterMagic();recoveryEnabled=false;resonanceEnabled=false;slingEnabled=true;seedWell();sling.setWell(magic.wells.find(w=>w.active));
 startFlight(22);yaw=targetYaw=0;pitch=targetPitch=0;toast('鼠标按住尾端亮点，向目标反方向拉。看准虚线轨迹，松手送光。');
}
$('sling-start').onclick=()=>{if(slingEnabled){cancelStudioInput();slingEnabled=false;}else enterSling();};
function enterRecovery(){
 enterMagic();slingEnabled=false;resonanceEnabled=false;recoveryEnabled=true;
 magic.reset();bridge.reset(magic.burstEpoch);recovery.reset(magic.burstEpoch);resetView();
 toast('让引力桥接住星尘，等它滑入奇点，再选择引爆释放。没有倒计时。');
}
function restartRecovery(){cancelStudioInput();magic.reset();bridge.reset(magic.burstEpoch);recovery.reset(magic.burstEpoch);}
function placeRecoveryNet(){
 if(!recoveryEnabled||recovery.state.won||paused||flight.active||viewDistance>=45||magic.wells.some(w=>w.active||w._cooldown>0))return;
 cancelStudioInput();
 for(const [id,x]of [['recovery-left',-2.35],['recovery-right',2.35]]){if(magic.summon(id,{x,y:1.05,z:2.65},{fresh:true}))magic.parkSummoned(id);}
 toast('回收网已布置。靠近一个奇点，用拇中指捏合托起；鼠标移近后按 C。');
}
function recoveryHint(){
 if(paused)return '时间暂停，已暂存星尘会留在奇点中。';
 if(flight.active)return '镜头正在自动航行，星尘会留在原来的奇点中。';
 if(viewDistance>=45)return '选择「黑洞」返回近景，继续救回星尘。';
 if(recovery.state.won)return recovery.state.label+' · 可重启回收再试一次';
 if(recovery.state.stored&&!casting.activeCount)return webcamState.active||renderer.xr.isPresenting?'靠近奇点，拇中指捏合重新托起，再握拳救回星尘。':'鼠标移近一个奇点，按 C 重新托起，再按 F 救回星尘。';
 if(!magic.wells.some(w=>w.active))return '创建两个奇点连成桥，或点击「布置回收网」开始。';
 if(magic.wells.filter(w=>w.active).length===1)return '再创建一个奇点，与第一个拉开距离，连成引力桥。';
 return recovery.state.label;
}
function readResonanceGuide({xr=false,needsOpen=false,calibrationBlocked=false,castTransition={}}={}){
 const hold=(phase,label)=>({phase,label,targetId:null,reachableIds:[]});
 if(calibrationBlocked)return hold('calibration',webcamState.calibration?.label||'跟随右侧步骤，镜头暂时保持。');
 if(paused)return hold('paused','时间暂停 · 星图进度已保留，继续后再移动奇点。');
 if(imageTargets)return hold('image','点击「返回黑洞」，继续唤醒星图。');
 if(demo)return hold('demo','漫游演示中 · 点击画面接管后继续星图。');
 if(casting.state.recovering)return hold('recovering','把同一只手张掌带回镜头，奇点会从原处接上。');
 if(flight.active)return hold('flight','镜头正在航行 · 抵达后选择「黑洞」继续星图。');
 if(viewDistance>=45)return hold('distant','选择「黑洞」返回近景，继续唤醒星球。');
 if(resonance.state.won||magic.state.burstPending||resonance.waves.length&&!magic.wells.some(well=>well.active))
  return resonanceGuide.update({won:resonance.state.won,burstPending:!!magic.state.burstPending,waves:resonance.waves});
 if(needsOpen)return hold('release','先张掌一次，再用拇中指创造奇点，靠近未点亮的星球。');
 if(castTransition.label)return hold('release',castTransition.label);
 if(navResult.active&&navResult.mode==='orbit')return hold('orbit','正在转动视角 · 松开拇食指后继续唤醒星球。');
 if(placementArmed)return hold('placement','用鼠标点击星球附近放置奇点，再靠近奇点重新托起。');
 if(demoCast?.awaitTarget)return hold('regrab','把鼠标移到留驻奇点上，便可重新托起；Escape 取消。');
 if(creationCooling()&&!resonance.waves.length)return hold('cooling','光流正在稳定 · 稍候再创造奇点，星图进度会保留。');
 const wells=magic.wells.filter(well=>well.active);
 return resonanceGuide.update({wells,preview:resonance.previewBurst(wells),won:resonance.state.won,
  burstPending:!!magic.state.burstPending,waves:resonance.waves,
  casting:{activeCount:casting.activeCount,hands:[...casting.hands].map(([id,hand])=>({id,holding:hand.holding,burstReady:hand.burstReady,phase:hand.phase,present:hand.present,recovering:hand.recovering}))},
  demo:demoCast?{id:'demo-cast',creating:!!demoCast.creating,awaitTarget:!!demoCast.awaitTarget}:null,
  inputMode:demoCast?'mouse':xr?'xr':webcamState.active?'camera':'mouse'});
}
function updateRecovery(dt,enabled){
 if(enabled)recovery.acceptBurst(magic.burstEpoch,magic.lastBurstOrigins);
 recovery.update(dt,bridge,magic.wells,{enabled});
}
$('recovery-start').onclick=()=>{if(recoveryEnabled){cancelStudioInput();recoveryEnabled=false;}else enterRecovery();};
$('recovery-reset').onclick=restartRecovery;
$('recovery-net').onclick=placeRecoveryNet;
$('resonance-start').onclick=()=>{if(resonanceEnabled){cancelStudioInput();resonanceEnabled=false;}else{enterMagic();recoveryEnabled=false;slingEnabled=false;resonanceEnabled=true;magic.reset();bridge.reset(magic.burstEpoch);recovery.reset(magic.burstEpoch);resonance.reset(magic.burstEpoch);resonanceGuide.reset();resetView();toast('先创造一个奇点，边缘提示会引导你靠近星球。没有倒计时。');}};
$('resonance-reset').onclick=()=>{cancelStudioInput();magic.reset();bridge.reset(magic.burstEpoch);recovery.reset(magic.burstEpoch);resonance.reset(magic.burstEpoch);resonanceGuide.reset();};
$('sling-reset').onclick=()=>{cancelStudioInput();sling.reset();seedWell();sling.setWell(magic.wells.find(w=>w.active));};
$('place-well').onclick=()=>{if(interactionMode!=='studio')enterMagic();cancelStudioInput();placementArmed=!placementArmed;if(placementArmed&&viewDistance>=45)startFlight(16);};
$('magic-game').onclick=()=>$('start-game').click();
$('magic-clear').onclick=()=>{cancelStudioInput();magic.reset();bridge.reset(magic.burstEpoch);recovery.reset(magic.burstEpoch);resonance.reset(magic.burstEpoch);resonanceGuide.reset();sling.setWell(null);placementArmed=false;};
$('flight-stop').onclick=()=>{cancelStudioInput();stopFlight();};
function setInteractionHelp(open,{restoreFocus=false}={}){
 helpOpen=open;$('interaction-help').hidden=!open;$('magic-demo').setAttribute('aria-expanded',String(open));
 if(open){setPanel(false);$('interaction-help-close').focus({preventScroll:true});}
 else if(restoreFocus&&!$('magic-dock').hidden)$('magic-demo').focus({preventScroll:true});
}
$('magic-demo').onclick=()=>setInteractionHelp(!helpOpen);
$('interaction-help-close').onclick=()=>setInteractionHelp(false,{restoreFocus:true});
function goTo(destination){if(imageTargets)clearImage();if(interactionMode!=='studio')setMode('studio');stopDemonstrations();startFlight(stationDistance(destination,{sling:slingEnabled}));}
document.querySelectorAll('[data-destination]').forEach(button=>button.onclick=()=>goTo(button.dataset.destination));
function travelStep(direction){const next=nextStation(viewDistance,direction,{sling:slingEnabled,flightTarget:flight.active?flight.target:null});goTo(next.id);}
$('travel-out').onclick=()=>travelStep(1);$('travel-in').onclick=()=>travelStep(-1);
function findMouseRegrab(){
 if(!pointer.inside)return null;const slot=pickWell(pointer.nx,pointer.ny),well=magic.wells[slot];if(!well?.active||well._summonOwner!=null||well._grabbedBy!=null)return null;
 camera.getWorldDirection(viewNormal);const depth=-viewNormal.dot(sculpture.localToWorld(new THREE.Vector3(well.x,well.y,well.z)));
 return{targetId:well.id,point:{x:well.x,y:well.y,z:well.z},depth};
}
function creationCooling(){return magic.wells.length>0&&magic.wells.every(w=>!w.active&&w._cooldown>0);}
function startMouseCast({regrab=false}={}){
 if(orbitPractice.state.active||webcamState.inputBlocked)return;
 if(paused||flight.active||viewDistance>=45||interactionMode!=='studio'||magic.state?.burstPending||creationCooling())return;
 if(regrab&&!magic.wells.some(w=>w.active&&w._summonOwner==null&&w._grabbedBy==null))return;
 stopDemonstrations();navigation.reset();targetYaw=yaw;targetPitch=pitch;
 const p=screenHand('demo-cast',pointer.inside?pointer.nx:.48,pointer.inside?pointer.ny:.16,2.65,false);
 if(demoCast){magic.parkSummoned('demo-cast');casting.reject('demo-cast');}
 demoCast={gesture:'open',point:{x:p.x,y:p.y,z:p.z},depth:2.65,elapsed:0,creating:true,palmRoll:0,awaitTarget:regrab||magic.wells.every(w=>w.active)};
}
function releaseMouseCast(){if(webcamState.inputBlocked)return;if(demoCast&&!demoCast.creating&&!demoCast.awaitTarget){demoCast.gesture='fist';demoCast.elapsed=0;}}
$('cast-toggle').onclick=()=>startMouseCast();
$('cast-regrab').onclick=()=>startMouseCast({regrab:true});
$('cast-burst').onclick=releaseMouseCast;
$('cosmic-zoom').oninput=e=>{const value=+e.target.value;stopDemonstrations();cancelStudioInput();stopFlight();setDistance(MIN_DISTANCE*Math.pow(MAX_DISTANCE/MIN_DISTANCE,value/1000));viewDistance=distance;};
$('cosmic-zoom').onpointerup=()=>{setDistance(viewDistance);};
$('cosmic-zoom').onpointercancel=()=>{setDistance(viewDistance);};
$('explore-mode').onclick=enterMagic;

function setOrbitSensitivity(value){
 const parsed=Number(value);orbitSensitivity=orbitPresets.includes(parsed)?parsed:1;
 $('orbit-sensitivity').value=String(orbitSensitivity);
 document.querySelectorAll('[data-orbit-sensitivity]').forEach(button=>button.setAttribute('aria-pressed',String(Number(button.dataset.orbitSensitivity)===orbitSensitivity)));
 $('practice-sensitivity-note').textContent=orbitSensitivity===1.45?'轻移就能转得更多；随时可以换回标准。':orbitSensitivity===.65?'同样的移动转得更细，适合慢慢找角度。':'想少挪动手，选「轻松」；想细调，选「细腻」。';
 try{localStorage.setItem('light-thief-orbit-sensitivity',String(orbitSensitivity));}catch{}
}
function renderOrbitPractice(){
 const state=orbitPractice.state;
 document.body.classList.toggle('orbit-practice',state.active);
 $('navigation-practice').hidden=!state.active;
 $('practice-start').setAttribute('aria-expanded',String(state.active));
 $('practice-start').disabled=paused;
 const key=[state.active,state.complete,state.phase,state.label,state.hint,...state.stars].join('|');
 if(key===practiceRenderKey)return;practiceRenderKey=key;
 $('practice-title').textContent=state.label;
 $('practice-hint').textContent=state.hint;
 $('practice-progress').textContent=state.stars.filter(Boolean).length+' / 3';
 state.stars.forEach((lit,i)=>{const star=$('practice-star-'+i);star.classList.toggle('lit',lit);star.classList.toggle('active',state.active&&!lit&&state.stars.slice(0,i).every(Boolean));star.setAttribute('aria-label','第'+(i+1)+'颗引导星'+(lit?'已点亮':'待点亮'));});
 $('practice-retry').hidden=!state.complete;
 $('practice-exit').textContent=state.complete?'回到引力场':'结束练习';
}
function beginOrbitPractice(){
 if(paused||interactionMode!=='studio')return;
 stopDemonstrations();cancelStudioInput();stopFlight();placementArmed=false;
 setInteractionHelp(false);setPanel(false);
 orbitPractice.start();renderOrbitPractice();
}
function endOrbitPractice(){
 if(!orbitPractice.state.active)return;
 orbitPractice.cancel();cancelStudioInput();renderOrbitPractice();
}
function updateOrbitPractice(hands,navigationResult,now,beforeYaw,beforePitch,enabled){
 if(orbitPractice.state.active&&interactionMode!=='studio')orbitPractice.cancel();
 orbitPractice.update({navigation:navigationResult,hands,ownerId:navigation.handId,appliedYawDelta:yaw-beforeYaw,appliedPitchDelta:pitch-beforePitch,now,enabled});
 renderOrbitPractice();
}
$('practice-start').onclick=beginOrbitPractice;$('practice-retry').onclick=beginOrbitPractice;$('practice-exit').onclick=endOrbitPractice;
$('orbit-sensitivity').onchange=e=>setOrbitSensitivity(e.target.value);
document.querySelectorAll('[data-orbit-sensitivity]').forEach(button=>button.onclick=()=>setOrbitSensitivity(button.dataset.orbitSensitivity));
$('reset').addEventListener('click',()=>{endOrbitPractice();setOrbitSensitivity(1);});
setOrbitSensitivity(orbitSensitivity);renderOrbitPractice();


function palmModeActive(){return cameraControlStyle==='palm'&&webcamState.active&&interactionMode==='studio'&&!renderer.xr.isPresenting;}
function palmCursorPoint(point){return{x:THREE.MathUtils.clamp(point.x*1.35,-.98,.98),y:THREE.MathUtils.clamp(point.y*1.35,-.98,.98)};}
function palmScenePoint(point,well){
 let depth=2.65;
 if(well){camera.getWorldDirection(viewNormal);depth=-viewNormal.dot(sculpture.localToWorld(new THREE.Vector3(well.x,well.y,well.z)));}
 const p=palmCursorPoint(point),world=screenHand('palm-easy',p.x,p.y,depth,false);
 return{x:world.x,y:world.y,z:world.z};
}
function palmSceneDelta(from,to,well){
 const a=palmScenePoint(from,well),b=palmScenePoint(to,well);
 return{x:b.x-a.x,y:b.y-a.y,z:b.z-a.z};
}
function palmDepthAssist(target,screen,well,dt){
 const control=palmControl.controller.state;
 if(pointer.down||control.zoomActive||Math.abs(control.yawDelta||0)+Math.abs(control.pitchDelta||0)>.0001||Math.abs(targetYaw-yaw)+Math.abs(targetPitch-pitch)>.002||Math.abs(Math.log(distance/viewDistance))>.01)return target;
 // A returned palm can sit far from its retained well. Depth assistance must
 // follow the light's actual projected destination, never the new hand anchor.
 const projectedTarget=sculpture.localToWorld(new THREE.Vector3(target.x,target.y,target.z)).project(camera);
 const visible=Number.isFinite(projectedTarget.x)&&Number.isFinite(projectedTarget.y)&&Math.abs(projectedTarget.x)<=.98&&Math.abs(projectedTarget.y)<=.98&&projectedTarget.z>-1&&projectedTarget.z<1;
 const planet=visible&&aimPlanet({x:projectedTarget.x/1.35,y:projectedTarget.y/1.35});
 if(!planet)return target;
 camera.getWorldDirection(viewNormal);
 const normal=worldVelocityToLocal(sculpture,viewNormal.clone()).normalize();
 // Near-surface attraction has lateral feedback too: forward-only motion
 // misses off-axis planets under perspective projection.
 const goal={x:planet.x-normal.x*(planet.radius+.45),y:planet.y-normal.y*(planet.radius+.45),z:planet.z-normal.z*(planet.radius+.45)};
 const delta=new THREE.Vector3(goal.x-target.x,goal.y-target.y,goal.z-target.z);
 delta.multiplyScalar(1-Math.exp(-dt*2.4)).clampLength(0,dt*3.5);
 return{x:target.x+delta.x,y:target.y+delta.y,z:target.z+delta.z};
}
function palmPlaneVelocity(velocity,point,well){
 // Project a short screen movement onto the held object's actual depth plane.
 const a=palmScenePoint(point,well),b=palmScenePoint({x:point.x+velocity.x*.08,y:point.y+velocity.y*.08},well);
 return{x:(b.x-a.x)/.08,y:(b.y-a.y)/.08,z:(b.z-a.z)/.08};
}
function palmAim(velocity,point,well){
 camera.getWorldDirection(viewNormal);
 const forward=worldVelocityToLocal(sculpture,viewNormal.clone());
 return findThrowAim({origin:well,direction:palmPlaneVelocity(velocity,point,well),viewForward:forward,
  targets:[{id:'black-hole',name:'黑洞',x:0,y:0,z:0,radius:1.05},...planetTargetsLocal(),...(resonanceEnabled?resonance.targets.filter(t=>!t.lit):[])]});
}
function palmSceneVelocity(velocity,point,well){
 const aim=palmAim(velocity,point,well);palmAimName=aim?.target.name||'';
 return aim?.velocity||palmPlaneVelocity(velocity,point,well);
}
function palmHitTest(hand){
 const cursor=palmCursorPoint({x:hand.palmX,y:hand.palmY}),point=screenPoint(cursor.x,cursor.y);
 for(const button of [...document.querySelectorAll('[data-palm-action]'),$('travel-out'),$('travel-in'),$('flight-stop')]){
  if(hitElement(button,point,2))return{id:button.id,explicit:true,action:button.disabled?'blocked':button.dataset.palmAction||(button.id==='flight-stop'?'observe':button.id)};
 }
 for(const element of [$('magic-dock'),$('zoom-rail'),$('settings'),$('interaction-help'),document.querySelector('.topbar')])if(hitElement(element,point))return{id:'panel',action:'blocked'};
 if(!palmControl.held&&!flight.active&&viewDistance<45){
  if(lightSeed.visible&&nearWorld(lightSeed.position,cursor.x,cursor.y,52))return{id:'light-seed',action:'create'};
  const target=findPalmTarget({hand:{palmX:cursor.x,palmY:cursor.y},wells:magic.wells.filter(w=>w.phase!=='flying'),width:viewport.clientWidth,height:viewport.clientHeight,
   project:w=>sculpture.localToWorld(new THREE.Vector3(w.x,w.y,w.z)).project(camera)});
  if(target)return{id:'well-'+target.targetId,action:'regrab',targetId:target.targetId};
 }
 return null;
}
function selectPalmTool(action){
 if(!palmModeActive()||paused||document.hidden||helpOpen||!$('settings').hidden)return;
 
 if(action==='create'&&(flight.active||viewDistance>=45||magic.state.burstPending||!magic.wells.some(w=>!w.active&&w._cooldown<=0)))return;
 if(action==='park'&&!palmControl.held)return;
 if(action==='burst'&&!magic.wells.some(w=>w.active&&!w._burstPending))return;
 palmState=palmControl.select(action,performance.now());
}
function setPrimaryHand(side){
 primaryHand=side==='Left'?'Left':'Right';
 palmState=palmControl.setPrimaryHand(primaryHand);
 targetYaw=yaw;targetPitch=pitch;stopFlight();
 $('primary-hand').value=primaryHand;
 try{localStorage.setItem('light-thief-primary-hand',primaryHand);}catch{}
 toast((primaryHand==='Right'?'右手':'左手')+'固定为主手；另一只手控制视角和远近。');
}
$('primary-hand').value=primaryHand;
$('primary-hand').onchange=e=>setPrimaryHand(e.target.value);
function setInterfaceHidden(hidden){
 interfaceHidden=!!hidden;
 if(interfaceHidden){setPanel(false);setInteractionHelp(false);}
 document.body.classList.toggle('ui-hidden',interfaceHidden);
 const button=$('interface-toggle');
 button.setAttribute('aria-pressed',String(interfaceHidden));
 button.setAttribute('aria-label',interfaceHidden?'显示界面（H）':'隐藏界面（H）');
 button.querySelector('.interface-label').textContent=interfaceHidden?'显示界面':'隐藏界面';
 button.title=interfaceHidden?'显示界面 · H 或 Esc':'隐藏界面 · H';
}
$('interface-toggle').onclick=()=>setInterfaceHidden(!interfaceHidden);
$('camera-control-style').value=cameraControlStyle;
$('camera-control-style').onchange=e=>{
 cancelStudioInput();stopFlight();endOrbitPractice();cancelPinchCalibration();
 cameraControlStyle=e.target.value==='classic'?'classic':'palm';
 try{localStorage.setItem('light-thief-camera-controls',cameraControlStyle);}catch{}
 setMode(interactionMode);
 toast(cameraControlStyle==='palm'?'已切换双手协作：主手托光，另一手转角':'已切换经典手势');
};
document.querySelectorAll('[data-palm-action]').forEach(button=>button.onclick=()=>selectPalmTool(button.dataset.palmAction));
function renderPalmControls(active){
 document.body.classList.toggle('palm-controls',active);$('palm-tools').hidden=!active;
 if(!active)return;
 const held=!!palmControl.held,burstAvailable=magic.wells.some(w=>w.active&&!w._burstPending);
 $('palm-tool-create').disabled=paused||flight.active||viewDistance>=45||!!magic.state.burstPending||!magic.wells.some(w=>!w.active&&w._cooldown<=0);
 $('palm-tool-observe').disabled=paused;
 for(const action of ['park','burst']){$('palm-tool-'+action).hidden=action==='park'?!held:!burstAvailable;$('palm-tool-'+action).disabled=paused||!!magic.state.burstPending;}
 for(const button of document.querySelectorAll('[data-palm-action]'))button.setAttribute('aria-pressed',String(button.dataset.palmAction===palmState.mode));
 for(const id of ['palm-tool-observe','palm-tool-create','palm-tool-park','palm-tool-burst','travel-out','travel-in','flight-stop']){
  const aimed=palmState.dwell?.id===id;$(id).classList.toggle('palm-aim',aimed);$(id).style.setProperty('--palm-progress',aimed?String(palmState.dwell.progress):'0');
 }
 const label=paused?'时间暂停':demoCast?'鼠标正在托举 · 放下后继续掌心互动':palmState.label;
 const resuming=!held&&(palmState.resumeProgress||0)>0,creating=!held&&(palmState.createProgress||0)>0;
 const progress=resuming?palmState.resumeProgress:palmState.createProgress||0;
 $('palm-create-progress').hidden=!(creating||resuming);$('palm-create-progress').value=progress;
 $('palm-create-label').hidden=!(creating||resuming);$('palm-create-label').textContent=(resuming?'正在接回 ':'正在凝聚 ')+Math.round(progress*100)+'% · 小幅晃动没关系';
 $('secondary-status').textContent=palmState.navigationLabel||(primaryHand==='Right'?'左手':'右手')+'：挥动转角 · 握拳持续拉远';
 $('palm-light-readout').hidden=!held;
 const stored=THREE.MathUtils.clamp(palmControl.held?.storedEnergy||0,0,3);
 $('palm-light-progress').value=stored;$('palm-light-value').textContent=stored.toFixed(1)+' / 3';
 $('palm-status').textContent=label;$('gesture-label').textContent=label;
 $('palm-charge').hidden=!burstAvailable;$('palm-charge').value=palmState.charge||0;
 $('palm-charge-label').hidden=!burstAvailable;$('palm-charge-label').textContent=palmState.charge>0?'双拳蓄爆 '+Math.round(palmState.charge*100)+'% · 张开取消':'双拳稍停引爆 · 单主手握拳推进';
 $('travel-status').textContent=flight.active?'自动航行中 · 点「停在这里」可停下':'掌心光点停留选站 · 移开后可再选';
 const mainName=primaryHand==='Right'?'右手':'左手',secondaryName=primaryHand==='Right'?'左手':'右手';
 $('camera-badge').textContent=resuming?'张掌稍停 · 接回奇点 '+Math.round(progress*100)+'%':mainName+'主手 · '+secondaryName+'视角';
 const readyDirection=palmControl.controller.ready?.direction;
 const aimed=held&&readyDirection&&palmState.point?palmAim(readyDirection,palmState.point,palmControl.held):null;
 const reachable=resonanceEnabled&&held?resonance.previewBurst(magic.wells.filter(w=>w.active)).filter(t=>t.reachable).map(t=>t.name):[];
 $('palm-world-hint').textContent=palmState.resumeAvailable?'主手回到舒服的位置，张掌稍停接回上一颗奇点。':planetHint?planetHint:aimed?'已对准「'+aimed.target.name+'」· 辅助对齐深度':recoveryEnabled?'等星尘滑入奇点后，选「引爆」救回。':slingEnabled?'此挑战用鼠标反向拉动尾端亮点，松手送光。':reachable.length?'爆心覆盖「'+reachable.join('、')+'」· 可选择引爆':resonanceEnabled?'带着奇点靠近未点亮的星球，再双拳或点「引爆」。':held?'带着奇点靠近星球吸收能量 · 副手挥动带出余势':(viewDistance>=45?'主手握拳推进返回 · 副手握拳继续拉远 · 张开即停':'主手在空处自然张掌稍停，自动创造；轻微晃动不影响。');

 if(recoveryEnabled)$('recovery-status').textContent='沿桥运送 '+recovery.state.riding+' · 暂存 '+recovery.state.stored+' · 引爆后计入回收';
}

function resize(){const w=recordingSize?.width||viewport.clientWidth,h=recordingSize?.height||viewport.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();pipeline.resize(w,h,qualityRatio);uniforms.uPixel.value=qualityRatio;}
new ResizeObserver(resize).observe(viewport);resize();
let recordResultURL=null,recordDimensions='';
function renderRecording(state){
 const busy=['starting','recording','stopping'].includes(state.phase),result=state.result;
 $('recording-panel').dataset.phase=state.phase;
 $('record-start').hidden=busy;$('record-start').disabled=state.phase==='unsupported';
 $('record-start').textContent=result?'再录一段':'开始录制';
 $('record-stop').hidden=!busy;$('record-stop').disabled=state.phase==='stopping';
 $('record-stop').textContent=state.phase==='starting'?'取消准备':state.phase==='stopping'?'正在保存…':'停止并保存';
 $('record-close').disabled=busy;
 const seconds=Math.floor((state.elapsedMs||0)/1000),elapsed=String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');
 $('record-status').textContent=state.phase==='recording'?'正在录制 '+elapsed+' · 你可以继续用双手指挥':state.message||'直接录制作品画面与音乐，界面和摄像头原画不会录入。';
 $('record-detail').textContent=busy?(recordDimensions+' · 30 帧/秒目标 · '+((state.bytes||0)/1048576).toFixed(1)+' MB'):result?(recordDimensions+' · '+result.extension.toUpperCase()+' · '+(result.hasAudio?'已包含音乐音轨':'无音乐音轨')):'高清画面 · 30 帧/秒 · 最长 5 分钟，容量满时提前结束';
 $('record-download').hidden=!result;$('record-preview').hidden=!result;
 if(result&&result.url!==recordResultURL){recordResultURL=result.url;$('record-download').href=result.url;$('record-download').download=result.filename;$('record-preview').src=result.url;}
 if(!result&&recordResultURL){$('record-preview').pause();$('record-preview').removeAttribute('src');$('record-preview').load();$('record-download').removeAttribute('href');recordResultURL=null;}
 $('record-open').textContent=busy?'录制中':'录制';
}
const artworkRecorder=createArtworkRecorder({canvas,getAudioStream:()=>getMusicRecordingStream({userGesture:true}),onStateChange:renderRecording,
 onBegin:()=>{
  if(renderer.xr.isPresenting)throw new Error('请先退出空间模式，再录制桌面画面。');
  const ratio=Math.max(.2,viewport.clientWidth/Math.max(1,viewport.clientHeight));
  const height=Math.min(1080,1920/ratio),width=height*ratio;
  recordingSize={width:Math.max(2,Math.round(width/2)*2),height:Math.max(2,Math.round(height/2)*2)};
  recordDimensions=recordingSize.width+' × '+recordingSize.height;
  qualityRatio=1;renderer.setPixelRatio(1);resize();setPanel(false);setInteractionHelp(false);
 },
 onEnd:()=>{recordingSize=null;qualityRatio=renderBudget.state.pixelRatio;renderer.setPixelRatio(qualityRatio);resize();}
});
$('record-open').onclick=()=>{$('recording-panel').hidden=false;renderRecording(artworkRecorder.state);};
$('record-close').onclick=()=>{$('recording-panel').hidden=true;};
$('record-start').onclick=()=>{void artworkRecorder.start();};
$('record-stop').onclick=()=>{void artworkRecorder.stop();};
document.addEventListener('visibilitychange',()=>{if(document.hidden&&['starting','recording'].includes(artworkRecorder.state.phase))void artworkRecorder.stop('background');});
window.addEventListener('pagehide',()=>artworkRecorder.dispose());
function toast(message){$('toast').textContent=message;$('toast').style.opacity=1;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').style.opacity=0,4000);}
function setPanel(open){if(open)setInteractionHelp(false);$('settings').hidden=!open;document.body.classList.toggle('panel-open',open);$('settings-toggle').setAttribute('aria-expanded',String(open));}
$('settings-toggle').onclick=()=>setPanel($('settings').hidden);$('settings-close').onclick=()=>setPanel(false);
function beginPinchCalibration(){
 if(paused||renderer.xr.isPresenting||interactionMode!=='studio'){toast('请在摄像头引力漫游中校准。');return;}
 if(!startPinchCalibration())return;
 cancelStudioInput();stopFlight();stopDemonstrations();endOrbitPractice();placementArmed=false;
 pointer.down=false;pointer.pendingClick=false;pointer.releaseUntil=0;setPanel(false);
}
$('camera-calibrate').onclick=beginPinchCalibration;$('pinch-calibrate').onclick=beginPinchCalibration;
$('pinch-calibration-cancel').onclick=()=>cancelPinchCalibration();
$('pinch-calibration-reset').onclick=()=>resetPinchCalibration();
$('fullscreen').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else viewport.requestFullscreen?.().catch(()=>toast('此浏览器暂不支持全屏'));};
function resetView(){if(webcamState.calibration?.active)cancelPinchCalibration();cancelStudioInput();stopFlight();targetYaw=0;targetPitch=slingEnabled&&interactionMode==='studio'?0:.11;setDistance(slingEnabled&&interactionMode==='studio'?22:10.2);}
$('reset-view').onclick=()=>{stopDemonstrations();resetView();if(renderer.xr.isPresenting)placePending=true;};
$('pause').onclick=()=>{paused=!paused;if(paused){cancelPinchCalibration();cancelStudioInput();pointer.pendingClick=false;}$('pause').textContent=paused?'▷':'Ⅱ';$('pause').setAttribute('aria-label',paused?'继续':'暂停');};
function applyPalette(){let stops=paletteColors[$('palette').value];if(stops)stops.forEach((c,i)=>$('color-'+i).value=c);for(let i=0;i<3;i++)uniforms['uC'+i].value.set($('color-'+i).value);}
$('palette').onchange=applyPalette;for(let i=0;i<3;i++)$('color-'+i).oninput=()=>{$('palette').value='custom';applyPalette();};applyPalette();
$('amount').oninput=e=>{game.setCount(+e.target.value);geo.setDrawRange(0,game.count);$('amount-value').textContent=game.count.toLocaleString('en-US');};
$('power').oninput=e=>{power=+e.target.value;$('power-value').textContent=Math.round(power*100)+'%';};
$('glow').oninput=e=>{glow=+e.target.value;$('glow-value').textContent=Math.round(glow*100)+'%';pipeline.strength=.82*glow;};
function clearImage(){imageToken++;imageTargets=null;imageColors=null;uniforms.uImage.value=0;$('image-file').value='';$('image-info').hidden=true;game.reset();geo.setDrawRange(0,game.count);document.querySelector('.scene-caption>span').textContent='01 — 事件视界';document.querySelector('.scene-caption p').textContent='光抵达你的掌心，或坠入永夜。';}
$('start-game').onclick=()=>{setMode('play');if(imageTargets)clearImage();demo=false;$('demo').textContent='观看漫游演示';paused=false;$('pause').textContent='Ⅱ';$('pause').setAttribute('aria-label','暂停');game.startRound();$('round-label').textContent='夺光进行中';setPanel(false);};
$('demo').onclick=()=>{const next=!demo;setMode('explore');demo=next;demoTime=0;if(demo){paused=false;$('pause').textContent='Ⅱ';$('pause').setAttribute('aria-label','暂停');stopCamera();if(imageTargets)clearImage();game.reset();resetView();toast('从黑洞到行星群，再沿悬臂拉远到银河');}else game.reset();$('demo').textContent=demo?'停止演示':'观看漫游演示';setPanel(false);};
$('reset').onclick=()=>{stopCamera();resetMusic();clearImage();setMode('studio');magic.reset();galaxy.reset(magic.burstEpoch);bridge.reset(magic.burstEpoch);recovery.reset(magic.burstEpoch);resonance.reset(magic.burstEpoch);resonanceGuide.reset();resonanceEnabled=false;recoveryEnabled=false;sling.reset();slingEnabled=false;placementArmed=false;resetView();demo=false;paused=false;$('demo').textContent='观看漫游演示';$('pause').textContent='Ⅱ';for(const [id,value] of [['amount',32000],['power',1],['glow',1]]){$(id).value=value;$(id).dispatchEvent(new Event('input'));}$('palette').value='ice';applyPalette();toast('引力场已归位');};

// Mouse can explicitly manipulate tools; camera index contact is reserved for orbit.
const pointer={inside:false,down:false,orbit:false,nx:0,ny:0,vx:0,vy:0,last:0,releaseUntil:0,pendingClick:false,sampled:false};
function readPointer(e,preserveVelocity=false){const rect=canvas.getBoundingClientRect(),now=performance.now(),dt=Math.max(.016,(now-pointer.last)/1000),nx=(e.clientX-rect.left)/rect.width*2-1,ny=1-(e.clientY-rect.top)/rect.height*2;if(!preserveVelocity||now-pointer.last>120){pointer.vx=THREE.MathUtils.clamp((nx-pointer.nx)/dt,-6,6);pointer.vy=THREE.MathUtils.clamp((ny-pointer.ny)/dt,-6,6);}pointer.nx=nx;pointer.ny=ny;pointer.last=now;}
canvas.onpointerenter=()=>pointer.inside=true;canvas.onpointerleave=()=>{if(!pointer.down)pointer.inside=false;};
canvas.onpointerdown=e=>{if(webcamState.active)cancelStudioInput({keepPalm:palmModeActive()});if(demoCast){magic.parkSummoned('demo-cast');casting.reject('demo-cast');demoCast=null;navigation.reset();}stopDemonstrations();canvas.setPointerCapture(e.pointerId);pointer.inside=true;pointer.down=true;pointer.sampled=false;pointer.orbit=palmModeActive()||e.shiftKey||e.button===2;readPointer(e);};
canvas.onpointermove=e=>readPointer(e);
canvas.onpointerup=e=>{readPointer(e,true);if(pointer.down){pointer.pendingClick=!pointer.sampled;pointer.releaseUntil=performance.now()+300;}pointer.down=false;};
canvas.onpointercancel=()=>{pointer.releaseUntil=0;pointer.pendingClick=false;pointer.down=false;pointer.inside=false;pointer.orbit=false;cancelStudioInput();};canvas.oncontextmenu=e=>e.preventDefault();
canvas.addEventListener('wheel',e=>{e.preventDefault();stopDemonstrations();cancelStudioInput();stopFlight();setDistance(interactionMode==='studio'?distance*Math.exp(e.deltaY*.0017):THREE.MathUtils.clamp(distance+e.deltaY*.006,6.4,17));},{passive:false});
window.addEventListener('keydown',e=>{
 if(e.target?.closest?.('video,audio'))return;
 if(e.code==='KeyH'&&!e.repeat&&!/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)&&!e.target.isContentEditable){e.preventDefault();setInterfaceHidden(!interfaceHidden);return;}
 if(e.code==='Escape'&&interfaceHidden){e.preventDefault();setInterfaceHidden(false);return;}
 if(helpOpen&&$('interaction-help').contains(e.target)){if(e.code==='Escape'){e.preventDefault();setInteractionHelp(false,{restoreFocus:true});}return;}
 if(e.code==='Escape'&&helpOpen){e.preventDefault();setInteractionHelp(false,{restoreFocus:true});return;}
 if(webcamState.inputBlocked){if(e.code==='Escape')cancelPinchCalibration();if(/^(Key[CFRQE]|Arrow.+|Space|Minus|Equal|Escape)$/.test(e.code))e.preventDefault();return;}
 if(e.code==='Escape'){setPanel(false);placementArmed=false;cancelStudioInput();}
 if(!/INPUT|BUTTON|SELECT/.test(document.activeElement.tagName)){
  if(e.code.startsWith('Arrow')){cancelStudioInput();stopFlight();e.preventDefault();}
  if(e.code==='ArrowRight')targetYaw+=.18;if(e.code==='ArrowLeft')targetYaw-=.18;if(e.code==='ArrowUp')targetPitch=Math.min(1.3,targetPitch+.12);if(e.code==='ArrowDown')targetPitch=Math.max(-1.3,targetPitch-.12);
  if(e.code==='Minus'||e.code==='Equal'){cancelStudioInput();stopFlight();setDistance(distance*(e.code==='Minus'?1.4:1/1.4));}
 }
 if(interactionMode==='studio'&&e.code==='KeyC'&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)&&!document.activeElement.isContentEditable){e.preventDefault();if(!e.repeat){if(palmModeActive())selectPalmTool('create');else startMouseCast();}}
 if(interactionMode==='studio'&&e.code==='KeyR'&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)&&!document.activeElement.isContentEditable){e.preventDefault();if(!e.repeat)startMouseCast({regrab:true});}
 if(interactionMode==='studio'&&(e.code==='KeyF'||e.code==='Space'&&document.activeElement.tagName!=='BUTTON')&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)&&!document.activeElement.isContentEditable){e.preventDefault();if(!e.repeat){if(palmModeActive()&&magic.wells.some(w=>w.active&&!w._burstPending))selectPalmTool('burst');else releaseMouseCast();}}
 if(interactionMode==='studio'&&(e.code==='KeyQ'||e.code==='KeyE')&&demoCast&&!demoCast.creating&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)&&!document.activeElement.isContentEditable){e.preventDefault();demoCast.palmRoll+=(e.code==='KeyQ'?1:-1)*.22;}
 if(interactionMode==='play'&&e.code==='Space'&&!/INPUT|BUTTON|SELECT/.test(document.activeElement.tagName)){e.preventDefault();pointer.down=true;pointer.inside=true;}
});
window.addEventListener('keyup',e=>{if(e.code==='Space'){pointer.down=false;}});
window.addEventListener('keydown',e=>{if(!e.defaultPrevented&&e.code==='Escape')endOrbitPractice();});
window.addEventListener('blur',()=>{if(webcamState.calibration?.active)cancelPinchCalibration();pointer.inside=false;pointer.down=false;pointer.pendingClick=false;pointer.releaseUntil=0;cancelStudioInput();});
const ray=new THREE.Raycaster(),plane=new THREE.Plane(),viewNormal=new THREE.Vector3(),hit=new THREE.Vector3();
function screenHand(id,nx,ny,z=0,pinching=false,vx=0,vy=0,vz=0,closed=false){camera.getWorldDirection(viewNormal);plane.setFromNormalAndCoplanarPoint(viewNormal,viewNormal.clone().multiplyScalar(-z));ray.setFromCamera({x:nx,y:ny},camera);if(!ray.ray.intersectPlane(plane,hit))hit.set(0,0,z);const local=sculpture.worldToLocal(hit.clone()),right=new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,0),up=new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1),half=Math.tan(camera.fov*Math.PI/360)*camera.position.length();const velocity=right.multiplyScalar(vx*half*camera.aspect).addScaledVector(up,vy*half).addScaledVector(viewNormal,-vz);worldVelocityToLocal(sculpture,velocity,velocity);return{id,x:local.x,y:local.y,z:local.z,pinching,closed,vx:velocity.x,vy:velocity.y,vz:velocity.z};}
function pickWell(nx,ny){
 let slot=-1,best=34;
 magic.wells.forEach((well,i)=>{if(!well.active||well.phase==='flying')return;const p=sculpture.localToWorld(new THREE.Vector3(well.x,well.y,well.z)).project(camera);const pixels=Math.hypot((p.x-nx)*viewport.clientWidth*.5,(p.y-ny)*viewport.clientHeight*.5);if(p.z>-1&&p.z<1&&pixels<best){best=pixels;slot=i;}});return slot;
}
function magicScreenHand(id,nx,ny,pinching,extras={}){
 const held=magic.wells.findIndex(w=>w.active&&w._grabbedBy===id),targetSlot=held>=0?held:pickWell(nx,ny);
 let z=2.65;
 if(targetSlot>=0){camera.getWorldDirection(viewNormal);const w=magic.wells[targetSlot];z=-viewNormal.dot(sculpture.localToWorld(new THREE.Vector3(w.x,w.y,w.z)));}
 return {...screenHand(id,nx,ny,z,pinching),...extras,targetSlot};
}
// Regrabbing follows the visible object, including its actual depth after an orbit.
function palmCastInput(h){
 const pendingId=casting.targetIdFor(h.id);
 let regrabTargetId=pendingId,well=magic.wells.find(w=>w.active&&w._summonOwner===h.id)||magic.wells.find(w=>w.active&&w.id===pendingId);
 if(!well&&!casting.isActive(h.id)){
  const target=findPalmTarget({hand:h,wells:magic.wells.filter(w=>w.phase!=='flying'),width:viewport.clientWidth,height:viewport.clientHeight,
   project:w=>sculpture.localToWorld(new THREE.Vector3(w.x,w.y,w.z)).project(camera)});
  if(target){regrabTargetId=target.targetId;well=magic.wells.find(w=>w.id===target.targetId);}
 }
 let depth=2.65;
 if(well){camera.getWorldDirection(viewNormal);depth=-viewNormal.dot(sculpture.localToWorld(new THREE.Vector3(well.x,well.y,well.z)));}
 const p=h.xr?h:screenHand(h.id,h.palmX??h.nx,h.palmY??h.ny,depth,false);
 const point=h.xr?{x:h.palmWorldX??h.x,y:h.palmWorldY??h.y,z:h.palmWorldZ??h.z}:{x:p.x,y:p.y,z:p.z};
 return{...h,point,...(regrabTargetId!=null?{regrabTargetId}:{})};
}
const routes=new Map();
let hoverKind='orbit',studioMagicHands=[],palmRegrabHint=false;
function screenPoint(nx,ny){return{x:(nx*.5+.5)*viewport.clientWidth,y:(.5-ny*.5)*viewport.clientHeight};}
function hitElement(element,point,pad=0){
 if(!element||element.hidden||element.getClientRects().length===0)return false;
 const rect=element.getBoundingClientRect(),view=viewport.getBoundingClientRect(),x=point.x+view.left,y=point.y+view.top;
 const dock=element.closest('#magic-dock');
 if(dock&&dock!==element&&getComputedStyle(dock).overflowY!=='visible'&&getComputedStyle(element).position!=='fixed'){
  const clip=dock.getBoundingClientRect();
  if(rect.right<=clip.left||rect.left>=clip.right||rect.bottom<=clip.top||rect.top>=clip.bottom||x<clip.left||x>clip.right||y<clip.top||y>clip.bottom)return false;
  const heading=dock.querySelector('.game-heading');
  if(heading&&!heading.contains(element)){const cover=heading.getBoundingClientRect();if(x>=cover.left&&x<=cover.right&&y>=cover.top&&y<=cover.bottom)return false;}
 }
 return x>=rect.left-pad&&x<=rect.right+pad&&y>=rect.top-pad&&y<=rect.bottom+pad;
}
function nearWorld(point,nx,ny,radius=30){const p=sculpture.localToWorld(new THREE.Vector3(point.x,point.y,point.z)).project(camera);return p.z>-1&&p.z<1&&Math.hypot((p.x-nx)*viewport.clientWidth*.5,(p.y-ny)*viewport.clientHeight*.5)<radius;}
function updateCameraRestRecovery(now,{xr=false,studio=true,calibrationBlocked=false}={}){
 const needsRecovery=!!(navigation.awaitingOpen&&navigation.cameraReleaseOwner)||pointTravel.phase==='latched';
 const enabled=needsRecovery&&studio&&webcamState.active&&!xr&&!paused&&!demo&&!imageTargets&&!document.hidden&&!calibrationBlocked&&
  !pointer.down&&!pointer.pendingClick&&!(now<pointer.releaseUntil)&&!demoCast&&!placementArmed&&
  !casting.activeCount&&!magic.grabbedCount&&!magic.state?.burstPending&&!sling.handle.grabbed&&$('settings').hidden&&!helpOpen;
 const result=cameraRestRecovery.update(webcamState.observation,webcamState.hands,now,{enabled,session:webcamState.session});
 if(result.action==='resume'){
  // A fresh open palm after a witnessed rest clears only old control locks.
  // Park any stale grip; neither the camera pose nor an ongoing flight changes.
  cancelStudioInput();routes.clear();pointTravel.reset();pointTravelResult=pointTravel.state;
  cameraRestNoticeUntil=now+1600;
 }
 cameraRestResult=result;
 return result.phase==='resting'||result.phase==='returning'||result.action==='resume';
}
function updatePointTravel(inputs,now,{xr=false,studio=true,calibrationBlocked=false}={}){
 const conflict=inputs.some(h=>h.indexPinching||h.middlePinching||h.gesture==='fist'||h.poseCandidate==='fist');
 const enabled=studio&&webcamState.active&&!xr&&!paused&&!demo&&!imageTargets&&!calibrationBlocked&&!document.hidden&&
  !orbitPractice.state.active&&!pointer.down&&!pointer.pendingClick&&!demoCast&&!placementArmed&&
  !casting.activeCount&&!magic.grabbedCount&&!magic.state?.burstPending&&!sling.handle.grabbed&&
  !navResult.active&&!navResult.recovering&&!conflict&&$('settings').hidden&&!helpOpen;
 const result=pointTravel.update(inputs.filter(h=>h.cameraInput),now,{enabled,targetForHand:hand=>{
  if(!Number.isFinite(hand.pointX)||!Number.isFinite(hand.pointY))return undefined;
  const point=screenPoint(hand.pointX,hand.pointY);
  for(const [id,direction] of [['travel-out',1],['travel-in',-1]]){
   const button=$(id);
   if(hitElement(button,point,4))return button.disabled?undefined:{id,direction};
  }
  return null;
 }});
 if(result.action==='travel')travelStep(result.direction);
 pointTravelResult=result;
 return result;
}
function chooseRoute(h){
 if(h.casting)return{kind:'ignore'};
 if(h.forceOrbit)return{kind:'orbit'};
 // A camera index pinch has one job, even when its projected fingertip lies
 // over a button, a well or a slingshot handle. Screen overlap is not a click.
 if(h.cameraInput&&h.indexPinching&&!h.middlePinching&&h.gesture!=='fist'&&h.poseCandidate!=='fist')return{kind:'orbit'};
 if(!h.xr){
  const point=screenPoint(h.nx,h.ny);
  if(hitElement($('interaction-help'),point))return{kind:'ignore',blockReason:'ui-region'};

  for(const button of document.querySelectorAll('[data-hand-action]'))if(!button.disabled&&hitElement(button,point,8))return{kind:'ui',button};
  if(hitElement($('zoom-rail'),point)||hitElement($('settings'),point)||hitElement($('magic-dock'),point)||hitElement(document.querySelector('.topbar'),point))return{kind:'ignore',blockReason:'ui-region'};
 }
 if(h.practiceOrbit)return{kind:'orbit'};
 if(viewDistance<45&&!flight.active){
  if(placementArmed)return{kind:'place'};
  if(slingEnabled&&sling.handle.active&&(h.xr?Math.hypot(h.x-sling.handle.x,h.y-sling.handle.y,h.z-sling.handle.z)<.4:nearWorld(sling.handle,h.nx,h.ny,28)))return{kind:'tail'};
  const slot=h.xr?magic.wells.findIndex(w=>w.active&&w.phase!=='flying'&&Math.hypot(w.x-h.x,w.y-h.y,w.z-h.z)<.6):pickWell(h.nx,h.ny);
  if(slingEnabled&&slot>=0)return{kind:'well',slot};
 }
 return{kind:'orbit'};
}
function localInput(h,route){
 if(h.xr)return{...h,targetSlot:route.kind==='place'?-1:route.slot};
 if(route.kind==='tail'){
  camera.getWorldDirection(viewNormal);const anchor=sling.handle.anchor,z=-viewNormal.dot(sculpture.localToWorld(new THREE.Vector3(anchor.x,anchor.y,anchor.z)));
  return screenHand(h.id,h.nx,h.ny,z,h.pinching);
 }
 return magicScreenHand(h.id,h.nx,h.ny,h.pinching,{targetSlot:route.kind==='place'?-1:route.slot,reacquired:h.reacquired,immediate:h.immediate});
}
function routeCasting(inputs,dt,{navigationOnly=false}={}){
 palmRegrabHint=false;
 // The raw pose can leave a fist before its stabilized label catches up. An
 // unambiguous index pinch already expresses navigation; a raw fist never does.
 inputs=inputs.map(h=>h.indexPinching&&!h.middlePinching&&h.poseCandidate!=null&&h.poseCandidate!=='fist'&&h.gesture==='fist'?{...h,gesture:h.poseCandidate}:h);
 const orbitIntent=interactionMode==='studio'&&!paused&&!demo&&inputs.some(h=>{
  const route=routes.get(h.id),index=h.id==='pointer'?h.pinching:h.indexPinching&&!h.middlePinching&&h.gesture!=='fist'&&h.poseCandidate!=='fist';
  if(!index||h.reacquired||!Number.isFinite(h.nx)||!Number.isFinite(h.ny)||route?.uiLatch)return false;
  // Keep an acquired tool/UI/lost-tracking route until its pinch is released.
  return route?.pinching?route.kind==='orbit':chooseRoute(h).kind==='orbit';
 });
 const spellHands=inputs.filter(h=>h.id!=='pointer'&&!h.navigationOnly).map(h=>{
  const route=routes.get(h.id),input=palmCastInput(h);
  // Camera middle pinches cast in space; overlapping a DOM panel is not a
  // button press. Keep actual tool/latch ownership checks below independent.
  const overUI=!h.xr&&!h.cameraInput&&['ui','ignore'].includes(chooseRoute({...h,pinching:false}).kind);
  if(!navigationOnly&&!orbitIntent&&!overUI&&!h.indexPinching&&!casting.isActive(h.id)&&input.regrabTargetId!=null)palmRegrabHint=true;
  return {...input,blocked:!casting.isActive(h.id)&&((!!route?.pinching&&route.kind!=='orbit')||overUI||sling.handle.grabbed)};
 });
 if(demoCast?.awaitTarget&&!magic.wells.some(w=>w.active)){demoCast=null;toast('奇点已释放，可以重新创造。');}
 if(demoCast?.awaitTarget){const target=findMouseRegrab();if(target){demoCast.point=target.point;demoCast.depth=target.depth;demoCast.targetId=target.targetId;demoCast.awaitTarget=false;demoCast.elapsed=0;}}
 if(demoCast&&!demoCast.awaitTarget){
  demoCast.elapsed+=Math.min(.05,dt);
  if(demoCast.creating){demoCast.gesture=demoCast.elapsed<.12?'open':demoCast.elapsed<.34?'middle':'open';if(demoCast.elapsed>=.46)demoCast.creating=false;}
  if(!pointer.inside)demoCast.pointerOrigin=null;
  if(pointer.inside&&demoCast.gesture==='open'){const p=screenHand('demo-cast',pointer.nx,pointer.ny,demoCast.depth??2.65,false);if(!demoCast.pointerOrigin){demoCast.pointerOrigin={x:p.x,y:p.y,z:p.z};demoCast.pointOrigin={...demoCast.point};}else for(const axis of ['x','y','z'])demoCast.point[axis]=demoCast.pointOrigin[axis]+p[axis]-demoCast.pointerOrigin[axis];}
  spellHands.push({id:'demo-cast',gesture:demoCast.gesture==='middle'?'neutral':demoCast.gesture,poseCandidate:demoCast.gesture==='middle'?'two':demoCast.gesture,middlePinching:demoCast.gesture==='middle',indexPinching:false,pinching:false,point:demoCast.point,palmRoll:demoCast.palmRoll,...(demoCast.targetId!=null?{regrabTargetId:demoCast.targetId}:{})});
 }
 // Park every carried well before the camera moves. Continue the lock for the
 // whole orbit grip, so a second hand cannot recast and seize the camera back.
 const actions=casting.update(spellHands,dt,{now:performance.now(),enabled:interactionMode==='studio'&&!paused&&!demo&&!flight.active&&viewDistance<45&&!orbitIntent&&!navigationOnly&&!webcamState.inputBlocked});
 const acted=new Set(),handedOff=new Set();
 for(const action of actions){
  acted.add(action.id);
  if(action.type==='summon'){navigation.reset();targetYaw=yaw;targetPitch=pitch;if(!magic.summon(action.id,action.point,{fresh:true,...(action.targetId!=null?{targetId:action.targetId}:{})})){casting.reject(action.id);if(action.id==='demo-cast')demoCast=null;toast(action.targetId!=null?'这个奇点已被占用或释放，张掌后重新选择。':magic.wells.some(w=>!w.active&&w._cooldown>0)?'光流正在稳定，请稍后再创造；已有奇点仍可重新托起。':'已有两个奇点。靠近留驻奇点重新抓取，或先引爆。');}}
  else if(action.type==='move')magic.moveSummoned(action.id,action.point,dt,action.palmRoll);
  else if(action.type==='freeze')magic.freezeSummoned(action.id);
  else if(action.type==='rebase')magic.rebaseSummoned(action.id,action.point,action.palmRoll);
  else if(action.type==='burstAll'){if(magic.burstAll(action.id)){sling.cancelGrab();for(const route of routes.values())if(['well','place','tail'].includes(route.kind))route.kind='ignore';}}
  else if(action.type==='park'){
   magic.parkSummoned(action.id);
   const input=inputs.find(h=>h.id===action.id);
   if(input?.indexPinching&&!casting.isActive(action.id)){handedOff.add(action.id);navigation.reset();routes.delete(action.id);}
  }
  if(action.type==='burstAll'&&action.id==='demo-cast')demoCast=null;
  if(action.type==='park'&&action.id==='demo-cast'&&!actions.some(a=>a.type==='summon'&&a.id===action.id))demoCast=null;
 }
 return inputs.map(h=>{
  const heldRoute=routes.get(h.id);
  if(heldRoute?.uiLatch&&h.id!=='pointer'){
   const released=(h.indexReleased===true||h.gesture==='open')&&h.gesture!=='fist'&&h.poseCandidate!=='fist'&&!h.middlePinching&&!h.indexPinching;
   const sampled=Number.isFinite(h.trackedAt);
   if(!released||h.reacquired||!Number.isFinite(dt)||dt<0||(dt>.2&&(!sampled||h.indexReleased!==true))){
    heldRoute.openTime=0;heldRoute.openSampleAt=undefined;heldRoute.openSamples=0;
   }else if(sampled){
    // Count real detector updates, never redraws of one old release sample.
    // Two continuous slow samples can confirm separation without treating a
    // long render frame itself as evidence that the fingers stayed open.
    const prior=heldRoute.openSampleAt,gap=h.trackedAt-prior;
    if(prior!==h.trackedAt){
     const continuous=prior!=null&&gap>0&&gap<450;
     heldRoute.openTime=(continuous?heldRoute.openTime||0:0)+Math.min(.05,continuous?gap/1000:dt);
     heldRoute.openSamples=(continuous?heldRoute.openSamples||0:0)+1;
     heldRoute.openSampleAt=h.trackedAt;
    }
   }else heldRoute.openTime=(heldRoute.openTime||0)+Math.min(.05,dt);
   if(heldRoute.openTime<.08||(sampled&&heldRoute.openSamples<2))return{...h,pinching:true,casting:true};
   heldRoute.uiLatch=false;
  }
  if(handedOff.has(h.id))return h;
  const claimed=casting.isActive(h.id)||acted.has(h.id)||h.middlePinching||h.gesture==='fist'||h.poseCandidate==='fist';
  if(claimed&&routes.get(h.id)?.kind==='tail'){sling.cancelGrab();routes.get(h.id).kind='ignore';}
  const keepLatch=routes.get(h.id)?.kind==='ignore'&&routes.get(h.id)?.pinching&&h.pinching;
  return claimed?{...h,pinching:!!keepLatch,casting:true}:h;
 });
}
function routeStudioHands(inputs,dt){
 // Navigation verifies continuous slow camera samples itself. Physical pulls
 // still cancel: unseen motion must never become a throw or placement.
 if(dt>.2&&([...routes.values()].some(r=>r.pinching&&['well','place','tail'].includes(r.kind))||sling.handle.grabbed||magic.grabbedCount)){cancelStudioInput({keepPalm:cameraControlStyle==='palm'&&webcamState.active&&!renderer.xr.isPresenting});for(const h of inputs)if(h.pinching)routes.set(h.id,{kind:'ignore',pinching:true});}
 studioMagicHands=[];const navHands=[],seen=new Set();hoverKind=inputs.length?chooseRoute(inputs[0]).kind:'orbit';
 for(const h of inputs){
  seen.add(h.id);let route=routes.get(h.id);
  // A tracking gap never turns into a release, a throw, or a new selection.
  if(h.reacquired&&route?.pinching&&!(h.cameraInput&&route.cameraInput&&route.kind==='orbit')){if(route.kind==='tail')sling.cancelGrab();if(route.kind==='well'||route.kind==='place')magic.releaseGrabs();route.kind='ignore';delete route.blockReason;navigation.reset();}
  if(!route){route={kind:'idle',pinching:false};routes.set(h.id,route);}
  if(h.pinching&&!route.pinching){
   delete route.blockReason;Object.assign(route,chooseRoute(h));route.cameraInput=!!h.cameraInput;
   if(route.kind!=='ui'&&route.kind!=='ignore'){stopFlight();targetYaw=yaw;targetPitch=pitch;}
   if(route.kind==='ui'){route.button.click();route.kind='ignore';route.uiLatch=h.id!=='pointer';route.openTime=0;route.openSampleAt=undefined;route.openSamples=0;}
   if(route.kind==='tail')sling.beginGrab(h.id,localInput(h,route));
   if(route.kind==='place')placementArmed=false;
  }
  if(route.kind==='well'||route.kind==='place'){
   if(h.pinching||route.pinching){studioMagicHands.push(localInput(h,route));if(slingEnabled&&route.slot!=null&&magic.wells[route.slot]?.active)sling.setWell(magic.wells[route.slot]);}
  }else if(route.kind==='tail'){
   if(h.pinching)sling.drag(h.id,localInput(h,route));else if(route.pinching){if(h.immediate)sling.drag(h.id,localInput(h,route));sling.release(h.id);}
  }
  if(!h.pinching&&!studioMagicHands.some(m=>m.id===h.id))studioMagicHands.push(h.xr?{...h,pinching:false}:screenHand(h.id,h.nx,h.ny,2.65,false));
  // A camera pinch engages the clutch; palm translation moves it. Tightening
  // the two fingertips must neither rotate the view nor cancel a real drag.
  const orbitPoint=h.cameraInput&&route.kind==='orbit'&&Number.isFinite(h.orbitX)&&Number.isFinite(h.orbitY)?{nx:h.orbitX,ny:h.orbitY}:{};
  navHands.push({...h,...orbitPoint,route:route.kind==='orbit'?'orbit':'other'});
  route.pinching=h.pinching;
  if(!h.pinching){route.kind='idle';route.slot=undefined;delete route.blockReason;}
 }
 for(const[id,route]of routes)if(!seen.has(id)&&route.pinching){if(route.kind==='tail')sling.cancelGrab();if(route.kind==='well'||route.kind==='place')magic.releaseGrabs();if(!(route.cameraInput&&route.kind==='orbit')){route.kind='ignore';delete route.blockReason;}}
 return navHands;
}
const beaconPositions=new Float32Array(6),beaconGeometry=new THREE.BufferGeometry();
beaconGeometry.setAttribute('position',new THREE.BufferAttribute(beaconPositions,3));
const beacons=new THREE.Points(beaconGeometry,new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
 vertexShader:'void main(){gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);gl_PointSize=4.;}',
 fragmentShader:'void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(.7,.87,1.,(1.-d*2.)*.8);}'}));beacons.frustumCulled=false;sculpture.add(beacons);
function updateBeacons(){let count=0;for(const w of magic.wells)if(w.active){beaconPositions.set([w.x,w.y,w.z],count*3);count++;}beaconGeometry.setDrawRange(0,count);beaconGeometry.attributes.position.needsUpdate=true;beacons.visible=interactionMode==='studio'&&viewDistance>=75&&!imageTargets;}
const xrHands=[];
for(let i=0;i<2;i++){const hand=renderer.xr.getHand(i),controller=renderer.xr.getController(i);scene.add(hand,controller);const dots=new THREE.Group();hand.add(dots);const joints=[];hand.addEventListener('connected',()=>{for(const dot of dots.children){dot.geometry.dispose();dot.material.dispose();}dots.clear();joints.length=0;for(const name of Object.keys(hand.joints)){const dot=new THREE.Mesh(new THREE.SphereGeometry(.005,6,4),new THREE.MeshBasicMaterial({color:0xccdbdf}));dots.add(dot);joints.push({name,dot});}});controller.addEventListener('connected',()=>controller.userData.connected=true);controller.addEventListener('selectstart',()=>controller.userData.pinch=true);controller.addEventListener('selectend',()=>controller.userData.pinch=false);controller.addEventListener('disconnected',()=>{controller.userData.pinch=false;controller.userData.connected=false;});xrHands.push({hand,controller,joints,previous:null,pinching:false});}
const a=new THREE.Vector3(),b=new THREE.Vector3();
const xrJointNames=['wrist','thumb-metacarpal','thumb-phalanx-proximal','thumb-phalanx-distal','thumb-tip','index-finger-phalanx-proximal','index-finger-phalanx-intermediate','index-finger-phalanx-distal','index-finger-tip','middle-finger-phalanx-proximal','middle-finger-phalanx-intermediate','middle-finger-phalanx-distal','middle-finger-tip','ring-finger-phalanx-proximal','ring-finger-phalanx-intermediate','ring-finger-phalanx-distal','ring-finger-tip','pinky-finger-phalanx-proximal','pinky-finger-phalanx-intermediate','pinky-finger-phalanx-distal','pinky-finger-tip'];
function readXRHands(dt){
 const result=[];
 xrHands.forEach((data,i)=>{
  for(const {name,dot}of data.joints){const joint=data.hand.joints[name];dot.visible=joint.visible;dot.position.copy(joint.position);}
  const previousIntent=data.intent;data.intent={indexPinching:false,middlePinching:false,palmRoll:0};
  const thumb=data.hand.joints['thumb-tip'],index=data.hand.joints['index-finger-tip'];let tracked=false,gesture='neutral',poseCandidate='neutral',palmPosition=null,palmSize=.18;
  if(thumb?.visible&&index?.visible){
   thumb.getWorldPosition(a);index.getWorldPosition(b);data.pinching=a.distanceTo(b)<(data.pinching?.04:.028);a.lerp(b,.5);tracked=true;
   if(xrJointNames.every(name=>data.hand.joints[name]?.visible)){
    const lm=xrJointNames.map(name=>data.hand.joints[name].getWorldPosition(new THREE.Vector3()));data.intent=classifyHandIntent(lm,previousIntent||{});const xrView=renderer.xr.getCamera().matrixWorldInverse,wr=lm[0].clone().applyMatrix4(xrView),mid=lm[9].clone().applyMatrix4(xrView);data.intent.palmRoll=Math.atan2(mid.y-wr.y,mid.x-wr.x);poseCandidate=data.intent.poseCandidate;data.poseState=stabilizeHandPose(data.poseState,poseCandidate,performance.now());gesture=data.poseState.gesture;palmPosition=new THREE.Vector3();for(const k of [0,5,9,13,17])palmPosition.addScaledVector(lm[k],.2);palmSize=lm[0].distanceTo(lm[9])/.7;
   }
  }else if(data.controller.userData.connected&&data.controller.visible){data.controller.getWorldPosition(a);data.pinching=!!data.controller.userData.pinch;data.intent.indexPinching=data.pinching;data.intent.indexReleased=!data.pinching;gesture=data.pinching?'two':'open';tracked=true;}
  if(tracked){const viewPoint=(palmPosition||a).clone().applyMatrix4(renderer.xr.getCamera().matrixWorldInverse),p=sculpture.worldToLocal(a.clone()),old=data.previous;result.push({nx:viewPoint.x/.35,ny:viewPoint.y/.35,palmX:viewPoint.x/.35,palmY:viewPoint.y/.35,palmSize,id:'xr'+i,x:p.x,y:p.y,z:p.z,...(palmPosition?(()=>{const palm=sculpture.worldToLocal(palmPosition.clone());return{palmWorldX:palm.x,palmWorldY:palm.y,palmWorldZ:palm.z};})():{}),reacquired:!old,pinching:data.pinching,indexPinching:data.intent?.indexPinching??data.pinching,middlePinching:data.intent?.middlePinching??false,indexReleased:data.intent?.indexReleased??false,palmRoll:data.intent?.palmRoll??0,gesture,poseCandidate,openPalm:gesture==='open',closed:gesture==='fist',vx:old?(p.x-old.x)/dt:0,vy:old?(p.y-old.y)/dt:0,vz:old?(p.z-old.z)/dt:0});data.previous=p;}else{data.previous=null;data.poseState=null;data.intent=null;}
 });return result;
}
function placeArtwork(){const cam=renderer.xr.getCamera();cam.getWorldPosition(a);cam.getWorldDirection(b);xrAnchor.copy(a).addScaledVector(b,1.7);xrAnchorRotation.copy(cam.quaternion);}
async function checkXR(){try{if(navigator.xr)for(const mode of ['immersive-ar','immersive-vr'])if(await navigator.xr.isSessionSupported(mode)){xrMode=mode;break;}}catch{}$('xr').disabled=!xrMode;$('xr').textContent=xrMode?'进入空间':'需 WebXR 头显';$('xr-status').textContent=xrMode?'支持空间追踪 · 黑洞作为悬浮物件呈现':'捏合转角 · 近一站 / 远一站漫游银河。';}
checkXR();$('xr').onclick=async()=>{if(recordingSize){toast('请先停止录制，再进入空间模式。');return;}try{if(renderer.xr.isPresenting){await renderer.xr.getSession().end();return;}stopCamera();const session=await navigator.xr.requestSession(xrMode,{optionalFeatures:['hand-tracking','local-floor']});if(recordingSize){await session.end();toast('录制进行中，空间模式已暂缓。');return;}await renderer.xr.setSession(session);cancelStudioInput();stopFlight();xrHands.forEach(h=>h.previous=null);placePending=true;setPanel(false);$('xr').textContent='退出空间';session.addEventListener('end',()=>{cancelStudioInput();universe.position.set(0,0,0);universe.quaternion.identity();universe.scale.setScalar(1);$('xr').textContent='进入空间';});}catch(error){toast('空间模式未能启动：'+error.message);}};

$('image-upload').onclick=()=>$('image-file').click();$('image-clear').onclick=clearImage;
$('image-file').onchange=async e=>{const file=e.target.files[0];if(!file)return;const token=++imageToken,url=URL.createObjectURL(file);try{const image=new Image();image.src=url;await image.decode();if(token!==imageToken)return;const sample=document.createElement('canvas'),ratio=image.width/image.height;sample.width=ratio>1?256:Math.max(1,Math.round(256*ratio));sample.height=ratio>1?Math.max(1,Math.round(256/ratio)):256;const ctx=sample.getContext('2d',{willReadFrequently:true});ctx.drawImage(image,0,0,sample.width,sample.height);const data=ctx.getImageData(0,0,sample.width,sample.height).data,pixels=[];for(let k=0;k<data.length;k+=4)if(data[k+3]>40)pixels.push(k/4);if(!pixels.length)throw new Error('这张图片完全透明，请换一张图片');const w=Math.min(6,4.8*ratio),h=w/ratio,targets=new Float32Array(MAX*3),cols=new Float32Array(MAX*3),c=new THREE.Color();for(let i=0;i<MAX;i++){const px=pixels[Math.floor(random()*pixels.length)],j=i*3,k=px*4;c.setRGB(data[k]/255,data[k+1]/255,data[k+2]/255,THREE.SRGBColorSpace);cols[j]=c.r;cols[j+1]=c.g;cols[j+2]=c.b;targets[j]=((px%sample.width+random())/sample.width-.5)*w;targets[j+1]=(.5-(Math.floor(px/sample.width)+random())/sample.height)*h;targets[j+2]=(c.r+c.g+c.b-1)*.16;}setMode('play');imageTargets=targets;imageColors=cols;displayColors.set(cols);geo.attributes.color.needsUpdate=true;uniforms.uImage.value=1;game.reset();demo=false;$('demo').textContent='观看漫游演示';$('image-info').hidden=false;$('image-name').textContent=file.name;document.querySelector('.scene-caption>span').textContent='02 — 光的记忆';document.querySelector('.scene-caption p').textContent='你的图像，正在星尘中重组。';resetView();targetPitch=0;toast('图片已化为粒子，可用手势互动');}catch(error){toast(error.message||'无法读取图片');}finally{URL.revokeObjectURL(url);}};

renderer.setAnimationLoop((now,frame)=>{
 const rawDt=lastTime?(now-lastTime)/1000:1/60,dt=Math.min(.033,Math.max(.001,rawDt));lastTime=now;updateMusic(dt,{analyze:false});const music=NEUTRAL_SCENE_MUSIC;if(!paused)time+=dt;
 const xr=renderer.xr.isPresenting;
 renderQuality=renderBudget.update(now,{camera:webcamState.active,xr});
 if(!xr&&!recordingSize&&qualityRatio!==renderQuality.pixelRatio){qualityRatio=renderQuality.pixelRatio;renderer.setPixelRatio(qualityRatio);resize();}
 pipeline.levelCount=renderQuality.bloomLevels;
 // Keep every physics object in the same local frame before hand projection.
 applySculptureFrame(sculpture,!!imageTargets);
 let xrInput=xr?readXRHands(dt):[];
 const studio=interactionMode==='studio';
 if(webcamState.active&&webcamState.session!==cameraSession){cameraSession=webcamState.session;cancelStudioInput();routes.clear();stopDemonstrations();stopFlight();}
 if(hadCamera&&!webcamState.active){cancelStudioInput();routes.clear();}hadCamera=webcamState.active;
 // Camera captures use performance.now(); a RAF timestamp can predate a
 // result already delivered before this callback. Compare using one live clock.
 const inputNow=performance.now();
 let studioInputs=[];
 const calibrationBlocked=!!webcamState.inputBlocked&&!xr;
 if((webcamState.controlEpoch||0)!==cameraControlEpoch){
  cameraControlEpoch=webcamState.controlEpoch||0;cancelStudioInput();stopFlight();stopDemonstrations();routes.clear();
  pointer.down=false;pointer.pendingClick=false;pointer.releaseUntil=0;navigation.awaitingOpen=calibrationBlocked;
 }
 const palmCamera=studio&&cameraControlStyle==='palm'&&webcamState.active&&!xr;
 const palmOverride=pointer.down||pointer.pendingClick||now<pointer.releaseUntil||!!demoCast;
 const recoveringFromRest=!palmCamera&&updateCameraRestRecovery(inputNow,{xr,studio,calibrationBlocked});
 const orbitBeforeYaw=yaw,orbitBeforePitch=pitch;
 if(studio&&!paused&&!demo&&!calibrationBlocked&&!recoveringFromRest){
  if(xr)studioInputs=xrInput.map(h=>({...h,xr:true,pinching:h.indexPinching??h.pinching}));
  else if(pointer.down||pointer.pendingClick||now<pointer.releaseUntil){studioInputs=[{id:'pointer',nx:pointer.nx,ny:pointer.ny,pinching:pointer.down||pointer.pendingClick,immediate:true,forceOrbit:pointer.orbit}];pointer.pendingClick=false;if(pointer.down)pointer.sampled=true;}
  else if(webcamState.active&&!palmCamera)studioInputs=webcamState.hands.filter(h=>!h.calibrationBlocked&&inputNow-h.trackedAt<(h.trackingGraceMs||350)).map(h=>({...h,cameraInput:true,pinching:h.indexPinching??h.pinching,nx:h.pinchX??h.nx,ny:h.pinchY??h.ny}));
  else if(!webcamState.active&&(pointer.inside||pointer.down||pointer.pendingClick||now<pointer.releaseUntil)){studioInputs=[{id:'pointer',nx:pointer.nx,ny:pointer.ny,pinching:pointer.down||pointer.pendingClick,immediate:true,forceOrbit:pointer.orbit}];pointer.pendingClick=false;if(pointer.down)pointer.sampled=true;}
 }
 if(slingEnabled)sling.setWell(magic.wells.find(w=>w.active&&w.phase!=='flying'&&w._grabbedBy)||(sling.well?.active&&sling.well.phase!=='flying'&&magic.wells.includes(sling.well)?sling.well:null)||magic.wells.find(w=>w.active&&w.phase!=='flying')||null);
 if(orbitPractice.state.active)studioInputs=studioInputs.map(h=>({...h,practiceOrbit:true}));
 studioInputs=routeCasting(studioInputs,rawDt,{navigationOnly:orbitPractice.state.active||calibrationBlocked});
 const navHands=studio?routeStudioHands(studioInputs,rawDt):[];
 if(palmCamera)palmState=palmControl.update(webcamState.hands,inputNow,{dt:rawDt,observation:webcamState.observation,
  enabled:!paused&&!demo&&!imageTargets&&!calibrationBlocked&&!document.hidden&&!demoCast&&!orbitPractice.state.active,
  blocked:helpOpen||!$('settings').hidden,allowOrbit:!palmOverride,allowManipulation:viewDistance<45,
  burstAvailable:magic.wells.some(w=>w.active&&!w._burstPending),
  allowThrow:!recoveryEnabled&&!slingEnabled,allowCreate:!flight.active&&viewDistance<45&&!magic.state.burstPending&&magic.wells.some(w=>!w.active&&w._cooldown<=0),hitTest:palmHitTest});
 if(studio){
  navResult=palmCamera&&!palmOverride?{active:!!(palmState.orbitActive||palmState.zoomActive),mode:palmState.zoomActive?'zoom':'orbit',released:palmState.navigationReleased,zoomStopped:!!palmState.zoomStopped,coasting:!!palmState.navigationCoasting,zoomDelta:palmState.zoomDelta||0,yawDelta:palmState.yawDelta*orbitSensitivity,pitchDelta:palmState.pitchDelta*orbitSensitivity,label:palmState.navigationLabel||palmState.label}:navigation.update(navHands,rawDt,{now:inputNow,yaw,pitch,distance:viewDistance,sensitivity:orbitSensitivity,enabled:!paused&&!demo&&!calibrationBlocked&&!studioMagicHands.some(h=>h.pinching)&&!sling.handle.grabbed&&!casting.activeCount});
  if(!paused){
   if(palmCamera&&!palmOverride&&palmState.navigationMode==='burst'){if(flight.active)stopFlight();targetYaw=yaw;targetPitch=pitch;setDistance(viewDistance);}
   targetYaw+=navResult.yawDelta||0;targetPitch=THREE.MathUtils.clamp(targetPitch+(navResult.pitchDelta||0),-1.3,1.3);
   if(palmCamera&&(navResult.zoomDelta||navResult.yawDelta||navResult.pitchDelta)){if(flight.active)stopFlight();if(navResult.zoomDelta)setDistance(distance*Math.exp(navResult.zoomDelta));}
   if(navResult.zoomStopped)setDistance(viewDistance);
   if(navResult.zoomValue!=null)setDistance(MIN_DISTANCE*Math.pow(MAX_DISTANCE/MIN_DISTANCE,navResult.zoomValue));
   if(navResult.active&&!palmCamera){yaw=targetYaw;pitch=targetPitch;}
   if(navResult.released){targetYaw=yaw;targetPitch=pitch;if(navResult.mode==='zoom'||!flight.active)setDistance(viewDistance);}
   if(flight.active)setDistance(flight.update(dt));
  }
  if(demo&&!webcamState.active){demoTime+=paused?0:dt;const t=demoTime%38;setDistance(t<8?10.2:t<16?10.2*Math.pow(90/10.2,smoothRange(t,8,16)):t<30?90*Math.pow(4300/90,smoothRange(t,16,30)):4300);targetYaw=Math.sin(demoTime*.13)*.22;}
 }
 if(!palmCamera)updatePointTravel(studioInputs,inputNow,{xr,studio,calibrationBlocked});
 viewDistance=Math.exp(THREE.MathUtils.damp(Math.log(viewDistance),Math.log(distance),4.5,dt));
 const wide=smoothRange(Math.log(viewDistance),Math.log(180),Math.log(2200));
 desiredFocus.copy(galaxy.center).multiplyScalar(wide);focus.copy(desiredFocus);
 yaw=THREE.MathUtils.damp(yaw,targetYaw,8,dt);pitch=THREE.MathUtils.damp(pitch,THREE.MathUtils.clamp(targetPitch,-1.35,1.35),8,dt);
 if(!xr){const fit=Math.max(1,1.12/camera.aspect),d=viewDistance*fit;camera.position.set(Math.sin(yaw)*Math.cos(pitch)*d,Math.sin(pitch)*d,Math.cos(yaw)*Math.cos(pitch)*d).add(focus);camera.lookAt(focus);camera.near=Math.max(.05,d*.00006);camera.updateProjectionMatrix();camera.updateMatrixWorld();}
 else{if(placePending&&frame){placeArtwork();placePending=false;}const rot=new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,-yaw,0));universe.quaternion.copy(xrAnchorRotation).multiply(rot);universe.scale.setScalar(.32*10.2/viewDistance);universe.position.copy(focus).multiplyScalar(-universe.scale.x).applyQuaternion(universe.quaternion).add(xrAnchor);}
 universe.updateMatrixWorld(true);let hands=[];
 updateOrbitPractice(navHands,navResult,now,orbitBeforeYaw,orbitBeforePitch,studio&&!paused&&!demo&&!flight.active&&!document.hidden);
 const castTransition=orbitCastTransition.update({hands:navHands,navigation:navResult,ownerId:navigation.handId,now:inputNow,
  enabled:studio&&!palmCamera&&webcamState.active&&!xr&&!paused&&!demo&&!flight.active&&viewDistance<45&&!orbitPractice.state.active&&!calibrationBlocked&&!document.hidden});
 if(castTransition.releaseId!=null)casting.resumeAfterNavigation(castTransition.releaseId);
 if(interactionMode==='play'){
  if(calibrationBlocked)hands=[];else if(xr)hands=xrInput;else if(webcamState.active&&!webcamState.inputBlocked){demo=false;hands=webcamState.hands.filter(h=>!h.navigationOnly&&!h.calibrationBlocked&&inputNow-h.trackedAt<(h.trackingGraceMs||350)).map(h=>screenHand(h.id,h.nx,h.ny,h.z,h.pinching,h.vx,h.vy,h.vz,h.closed));}
  else if(pointer.inside&&!pointer.orbit){hands=[screenHand('pointer',pointer.nx,pointer.ny,0,pointer.down,pointer.vx,pointer.vy)];pointer.vx*=Math.exp(-dt*8);pointer.vy*=Math.exp(-dt*8);}
 }
 if(webcamState.active&&demo){demo=false;$('demo').textContent='观看漫游演示';}
 if(!studio||webcamState.active||xr||paused){pointer.pendingClick=false;pointer.releaseUntil=0;}
 const magicHands=studio?studioMagicHands.map(h=>({...h,allowFlick:false})):[];
 if(xr)renderer.xr.updateCamera(camera);
 galaxy.update(time,xr?renderer.xr.getCamera():camera,viewDistance,{enabled:!imageTargets,musicEnergy:0,localVisibility:(slingEnabled||resonanceEnabled||recoveryEnabled)&&studio?smoothRange(viewDistance,35,65):1,wells:magic.wells.filter(w=>w.active).map(w=>universePoint({id:w.id,x:w.x,y:w.y,z:w.z,active:w.active,held:studio&&!paused&&(w._summonOwner!=null||w._grabbedBy!=null),energyCapacity:magic.planetLightCapacity(w.id),flying:w.phase==='flying',burstPending:w._burstPending})),burstOrigins:magic.lastBurstOrigins.map(universePoint),burstEpoch:magic.burstEpoch});
 if(studio&&!paused&&!imageTargets)transferPlanetLight();
 magic.setFlightTargets([...planetTargetsLocal(),...(resonanceEnabled?resonance.targets:[])]);
 planetHint=galaxy.interactionState?.label||'';
 if(!paused){game.update(Math.min(rawDt,.25),hands,music,{power,flow:1,imageTargets});magic.update(Math.min(rawDt,.25),magicHands,music);bridge.update(dt,magic.wells,music,{enabled:studio&&!imageTargets});bridge.acceptBurst(magic.burstEpoch,magic.lastBurstOrigins);updateRecovery(dt,studio&&recoveryEnabled&&!imageTargets&&viewDistance<60);if(studio&&viewDistance<180)magic.influenceField(game,dt);if(slingEnabled&&studio)sling.update(dt,magic.wells);if(resonanceEnabled&&studio){resonance.acceptBurst(magic.burstEpoch,magic.lastBurstOrigins);resonance.update(dt);}}
 const state=game.state;
 recoveryVisuals.update(time,xr?renderer.xr.getCamera():camera,{visible:studio&&recoveryEnabled&&!imageTargets&&viewDistance<60,pixelRatio:qualityRatio,glow});
 bridgeVisuals.update(time,xr?renderer.xr.getCamera():camera,{visible:studio&&!imageTargets&&viewDistance<60,pixelRatio:qualityRatio,glow});
 magicVisuals.update(time,xr?renderer.xr.getCamera():camera,{pixelRatio:qualityRatio,visible:studio&&!imageTargets&&viewDistance<90,glow});updateBeacons();
 supernova.update(time,xr?renderer.xr.getCamera():camera,{enabled:studio&&!imageTargets,paused,pixelRatio:qualityRatio,quality:[1,.8,.6,.45][renderQuality.tier],reduceMotion:reducedMotion.matches,glow});
 slingVisuals.update(time,xr?renderer.xr.getCamera():camera,{visible:studio&&slingEnabled&&!imageTargets&&viewDistance<55,pixelRatio:qualityRatio,glow});
 resonanceVisuals.update(time,xr?renderer.xr.getCamera():camera,{visible:studio&&resonanceEnabled&&!imageTargets&&viewDistance<55,pixelRatio:qualityRatio,glow});
 constellation.visible=studio&&resonanceEnabled&&resonance.state.won&&viewDistance<55&&!imageTargets;
 const cursorHand=palmCamera&&!palmOverride&&palmState.point&&palmState.phase!=='frozen'?{...palmCursorPoint(palmState.point),palmCursor:true}:!palmCamera&&!xr&&webcamState.active&&studio?(navResult.active&&navResult.mode==='orbit'?studioInputs.find(h=>h.id===navigation.handId):studioInputs.find(h=>h.id===pointTravelResult.ownerId)||studioInputs.find(h=>h.pointing)||studioInputs[0]):null;
 $('intent-cursor').hidden=!cursorHand;
 if(cursorHand){const pointing=cursorHand.pointing&&!navResult.active&&!casting.activeCount;const cx=cursorHand.palmCursor?cursorHand.x:pointing?cursorHand.pointX:cursorHand.nx,cy=cursorHand.palmCursor?cursorHand.y:pointing?cursorHand.pointY:cursorHand.ny;$('intent-cursor').style.left=(cx*.5+.5)*viewport.clientWidth+'px';$('intent-cursor').style.top=(-cy*.5+.5)*viewport.clientHeight+'px';$('intent-cursor').classList.toggle('grabbing',cursorHand.pinching);$('intent-cursor').classList.toggle('targeting',!cursorHand.palmCursor&&!(navResult.active&&navResult.mode==='orbit')&&hoverKind!=='orbit'&&hoverKind!=='ignore');}

 geo.setDrawRange(0,game.count);geo.attributes.position.needsUpdate=true;geo.attributes.aEnergy.needsUpdate=true;
 const owners=geo.attributes.aOwner.array;for(let i=0;i<game.count;i++)owners[i]=game.ownership[i];geo.attributes.aOwner.needsUpdate=true;
 const n=Math.min(TRAILS,game.count);trailGeo.setDrawRange(0,n*2);for(let i=0;i<n;i++){const index=Math.floor(i*game.count/n),j=index*3,k=i*6,owner=game.ownership[index],speed=Math.hypot(game.velocities[j],game.velocities[j+1],game.velocities[j+2]),length=owner===2?.07:.025;for(let c=0;c<3;c++){trailPos[k+c]=game.positions[j+c];trailPos[k+3+c]=game.positions[j+c]-game.velocities[j+c]*length;const color=owner>=0?c===0?.6:c===1?.83:1:c===0?.52:c===1?.7:.92;trailColors[k+c]=color*Math.min(2.2,speed*.3+.2);trailColors[k+3+c]=color*.04;}}trailGeo.attributes.position.needsUpdate=true;trailGeo.attributes.color.needsUpdate=true;
 uniforms.uTime.value=time;uniforms.uPitch.value=0;uniforms.uTick.value=0;uniforms.uBeat.value=0;uniforms.uMusic.value=0;uniforms.uGlow.value=.8+glow*.2;
 blackhole.update(time,xr?renderer.xr.getCamera():camera,{...state,raySteps:renderQuality.raySteps,drain:studio?magic.state.drain:0,singularities:studio?magic.wells:[],energy:0,colors:[uniforms.uC0.value,uniforms.uC1.value,uniforms.uC2.value],visible:!imageTargets&&viewDistance<850});
 nearField.update(time,viewDistance,{enabled:!imageTargets});
 particles.visible=trails.visible=viewDistance<180;
 lightSeed.visible=palmCamera&&!palmControl.held&&!palmState.resumeAvailable&&!paused&&!flight.active&&!imageTargets&&viewDistance<30&&magic.wells.some(w=>!w.active&&w._cooldown<=0);
 lightSeed.scale.setScalar(1+Math.sin(time*2.6)*.13+(palmState.dwell?.id==='light-seed'?(palmState.dwell.progress||0)*1.6:0));
 const occupiedLabels=[];
 for(const mark of markerNodes){if(mark.kind==='blackhole')mark.node.textContent=mark.name+(magic.state.activeCount?' · '+magic.state.activeCount+' 个奇点留驻':'');const visible=!imageTargets&&!xr&&studio&&(mark.kind==='blackhole'?viewDistance>70:mark.kind==='planet'?viewDistance>8&&viewDistance<240:mark.kind==='star'?viewDistance>30&&viewDistance<240:viewDistance>600);if(!visible){mark.node.style.opacity='0';continue;}projected.copy(mark.position);universe.localToWorld(projected);projected.project(camera);const onScreen=projected.z>-1&&projected.z<1&&Math.abs(projected.x)<.9&&Math.abs(projected.y)<.6;const px=(projected.x*.5+.5)*viewport.clientWidth,py=(-projected.y*.5+.5)*viewport.clientHeight,clear=onScreen&&!occupiedLabels.some(p=>Math.abs(p.x-px)<132&&Math.abs(p.y-py)<24);mark.node.style.opacity=clear?'1':'0';if(clear)occupiedLabels.push({x:px,y:py});mark.node.style.left=px+'px';mark.node.style.top=py+'px';}
 for(const mark of [...slingMarkers,...resonanceMarkers]){
  const isResonance=resonanceMarkers.includes(mark);
  const object=mark.handle?sling.handle:mark.target,show=studio&&(isResonance?resonanceEnabled:slingEnabled)&&!imageTargets&&!xr&&viewDistance<55&&(!mark.handle||sling.handle.active);
  if(!show){mark.node.hidden=true;continue;}projected.set(object.x,object.y,object.z);sculpture.localToWorld(projected);projected.project(camera);
  mark.node.hidden=projected.z<-1||projected.z>1||Math.abs(projected.x)>.92||Math.abs(projected.y)>.8;
  mark.node.style.left=(projected.x*.5+.5)*viewport.clientWidth+'px';mark.node.style.top=(-projected.y*.5+.5)*viewport.clientHeight+'px';
  if(!mark.handle){const wp=sculpture.localToWorld(new THREE.Vector3(object.x,object.y,object.z));const size=object.radius*viewport.clientHeight/(2*Math.tan(camera.fov*Math.PI/360)*camera.position.distanceTo(wp));mark.node.style.transform='translate('+Math.round(size+9)+'px,-50%)';}
  mark.node.textContent=mark.handle?(sling.handle.grabbed?'反向拉动 · 松手发射':'潮汐尾 · 抓住亮点'):object.name+(object.lit?' · 已点亮':'');mark.node.classList.toggle('lit',!!object.lit);
 }
 pipeline.render(scene,camera);
 if(now-lastHudUpdate>=100){
 lastHudUpdate=now;
 $('score').textContent=String(Math.round(state.score||0)).padStart(4,'0');$('held').textContent=state.held||0;$('lost').textContent=state.lost||0;$('timer').textContent=state.running?Math.ceil(state.timeLeft)+'s':state.timeLeft===0?'0s':'—';$('score-progress').style.width=Math.min(100,(state.score||0)/(state.goal||1500)*100)+'%';
 $('round-label').textContent=demo?'动作演示':state.running?'夺光目标 · '+state.goal:(state.won||state.timeLeft===0)?(state.won?'挑战达成':'本轮结束'):'自由探索';$('start-game').innerHTML=(state.running?'重新开始':'开始 60 秒夺光')+' <span>↗</span>';
 if(interactionMode==='play'&&state.message&&state.message!==lastMessage){lastMessage=state.message;$('move-name').textContent=state.message;messageUntil=time+2.8;}if(time>messageUntil)$('move-name').textContent='';
 $('game-message').textContent=state.running?'救回 '+state.goal+' 颗光 · 向外挥手并松开':(state.won||state.timeLeft===0)?(state.won?'你从永夜中夺回了光。再试一次？':'本轮救回 '+state.score+' 颗光。靠近吸积盘聚集后再抛出。'):demo?'模拟手掌正在聚集并抛出粒子。':'捏合聚光，挥手松开，让粒子逃离黑洞。';
 if(studio){
  const needsOpen=(webcamState.active||xr)&&casting.state.recoveryRequired&&!casting.activeCount&&!demoCast&&!navResult.active;
  const resonanceInstruction=resonanceEnabled?readResonanceGuide({xr,needsOpen,calibrationBlocked,castTransition}):null;
  const level=viewDistance<30?0:viewDistance<180?1:viewDistance<1200?2:3;
  $('scale-label').textContent=['黑洞近景','周围行星','悬臂星域','银河全景'][level];
  document.querySelector('.scene-caption>span').textContent=['01 — 事件视界','02 — 行星群','03 — 悬臂之中','04 — 银河全景'][level];
  document.querySelector('.scene-caption p').textContent=recoveryEnabled&&level===0?'在坠入永夜之前，把星尘接回来。':resonanceEnabled&&level===0?'把奇点送往沉睡的星球，让星图重新发光。':slingEnabled&&level===0?'借一缕潮汐，把光送往沉睡的行星。':['移动掌心，找到你的观察角度。','掠过行星，光仍留在出发的地方。','沿着悬臂向外，找到黑洞的坐标。','松开手，让银河停在你喜欢的角度。'][level];
  document.querySelectorAll('[data-destination]').forEach(button=>button.classList.toggle('active',button.dataset.destination===['hole','planets','arm','galaxy'][level]));
  const pct=Math.round(THREE.MathUtils.clamp(slingEnabled?sling.handle.charge:magic.state.charge||0,0,1)*100);
  $('magic-phase').textContent=calibrationBlocked?(webcamState.calibration?.title||'校准捏合'):castTransition.phase==='release'?'松开转角 · 准备创造':castTransition.phase==='ready'?'已松开 · 可以继续创造':needsOpen?'先张掌一次 · 解锁施法':demoCast?.awaitTarget?'移到奇点附近 · 重新托举':casting.activeCount?(casting.state.phase==='compressing'?'正在压缩 · 即将引爆':casting.state.phase==='creating'?casting.state.label:casting.state.recovering?'短暂遮挡 · 奇点保持':'掌心托举 · 转腕扭动光流'):placementArmed?'选择奇点落点':flight.active?'镜头航行中':recoveryEnabled?(recovery.state.won?'星尘已重获自由':'星尘回收'):resonanceEnabled?(resonance.state.won?'星图苏醒':'星图共振'):slingEnabled?(sling.state.won?'三颗行星已点亮':sling.handle.grabbed?'拉开潮汐 · 蓄势':'引力弹弓'):magic.grabbedCount?'拖动奇点':magic.state.activeCount?magic.state.activeCount+' 个奇点留驻':'拇食指轻捏 · 专心转角';
  $('magic-charge').innerHTML=recoveryEnabled?recovery.state.saved+'<small>/ '+recovery.state.goal+'</small>':resonanceEnabled?resonance.state.litCount+'<small>/ 3</small>':slingEnabled?sling.state.litCount+'<small>/ 3</small>':pct+'<small>%</small>';$('magic-progress').style.width=(recoveryEnabled?Math.min(100,recovery.state.saved/recovery.state.goal*100):resonanceEnabled?resonance.state.litCount/3*100:pct)+'%';
  $('recovery-status').hidden=!recoveryEnabled;$('recovery-status').textContent='沿桥运送 '+recovery.state.riding+' · 暂存 '+recovery.state.stored+' · 引爆后才计入回收';
  $('recovery-start').textContent=recoveryEnabled?'退出回收':'星尘回收 ↗';$('recovery-start').classList.toggle('active',recoveryEnabled);
  $('recovery-reset').hidden=!recoveryEnabled;$('recovery-net').hidden=!recoveryEnabled;
  $('recovery-net').disabled=recovery.state.won||paused||flight.active||viewDistance>=45||magic.wells.some(w=>w.active||w._cooldown>0);
  $('bridge-status').hidden=!(bridge.state.active&&viewDistance<60);$('bridge-status').textContent=bridge.state.label;
  $('magic-hint').textContent=resonanceInstruction?.label?resonanceInstruction.label:calibrationBlocked?(webcamState.calibration?.label||'跟随右侧步骤，镜头暂时保持。'):castTransition.label?castTransition.label:needsOpen?'先张开整掌片刻，再用拇中指创造奇点。普通捏合仍可转动视角。':demoCast?.awaitTarget?'把鼠标移到留驻奇点上，便可重新托起；Escape 取消。':casting.activeCount?(casting.state.phase==='creating'?'拇指与中指轻触，食指保持伸出。':casting.state.recovering?'把同一只手张掌带回镜头，奇点会从原处接上。':recoveryEnabled?recoveryHint():'张掌移动与转腕。完整握拳捏爆全部；拇食指捏合可放下奇点、接管镜头。'):placementArmed?'用鼠标点击画面放置。再次点击按钮可取消。':flight.active?'正在前往选定尺度。拇食指轻捏或点击「停在这里」接管。':viewDistance>=45?'点「近一站」逐层返回，或直接选择「黑洞」。':recoveryEnabled?recoveryHint():resonanceEnabled?resonance.state.message:slingEnabled?(sling.handle.active?'鼠标按住尾端亮点，向目标反方向拉。虚线是预计光路。':'点击「放置奇点」重建引光源，或重新挑战。'):webcamState.active?'捏合只转角；单根食指指向左侧远 / 近一站，停留选站。':'空处拇中指创造；靠近奇点重新托举。鼠标 R 托起已有奇点。';
  const travelBase=flight.active?flight.target:viewDistance;
  $('travel-in').disabled=travelBase<=stationDistance('hole',{sling:slingEnabled})*1.00001;
  $('travel-out').disabled=travelBase>=4300*.99999;
  $('travel-status').textContent=flight.active?'前往'+(SCALE_STATIONS.find(s=>Math.abs(stationDistance(s.id,{sling:slingEnabled})-flight.target)<.01)?.name||'选定尺度')+' · 捏合可停':(webcamState.active?(pointTravelResult.label||'单根食指指向按钮 · 停留选一站'):'一次一站 · 放下手也能抵达');
  for(const id of ['travel-out','travel-in']){const aiming=pointTravelResult.phase==='aiming'&&pointTravelResult.targetId===id;$(id).classList.toggle('point-aim',aiming);$(id).style.setProperty('--point-progress',aiming?String(pointTravelResult.progress):'0');}
  $('cast-toggle').disabled=paused||flight.active||viewDistance>=45;
  $('cast-toggle').textContent=creationCooling()?'光流正在稳定':demoCast?.awaitTarget?'等待选择奇点':magic.wells.every(w=>w.active)?'重新托举 · C':demoCast?'再造一个奇点':'创建奇点 · C';
  $('cast-toggle').disabled=paused||flight.active||viewDistance>=45||!!demoCast?.creating||!!demoCast?.awaitTarget||!!magic.state.burstPending||creationCooling();
  $('cast-regrab').hidden=!magic.wells.some(w=>w.active);$('cast-regrab').disabled=paused||flight.active||viewDistance>=45||!!demoCast?.creating||!!demoCast?.awaitTarget||!!magic.state.burstPending||!magic.wells.some(w=>w.active&&w._summonOwner==null&&w._grabbedBy==null);
  $('cast-burst').disabled=!demoCast||demoCast.creating||paused;
  $('resonance-start').textContent=resonanceEnabled?'退出星图':'星图共振 ↗';$('resonance-start').classList.toggle('active',resonanceEnabled);
  $('resonance-reset').hidden=!resonanceEnabled;$('resonance-targets').hidden=!resonanceEnabled;
  resonance.targets.forEach((target,i)=>{const node=$('resonance-target-'+i);node.classList.toggle('lit',target.lit);node.textContent=(target.lit?'✦ ':resonanceInstruction?.targetId===target.id?'→ ':'· ')+target.name+(!target.lit&&resonanceInstruction?.reachableIds.includes(target.id)?' · 可唤醒':'');});
  $('cast-toggle').classList.toggle('active',!!demoCast);
  $('flight-stop').hidden=!flight.active;$('place-well').textContent=placementArmed?'取消放置':'＋ 放置奇点';$('place-well').classList.toggle('active',placementArmed);
  $('sling-start').textContent=slingEnabled?'退出弹弓':'引力弹弓 ↗';$('sling-reset').hidden=!slingEnabled;$('sling-targets').hidden=!slingEnabled;
  sling.targets.forEach((target,i)=>{const node=$('sling-target-'+i);node.classList.toggle('lit',target.lit);node.textContent=(target.lit?'✦ ':'· ')+target.name;});
  $('mode-label').textContent=xr?'空间抓取':flight.active?'星际航行':recoveryEnabled?'星尘回收':resonanceEnabled?'星图共振':slingEnabled?'潮汐弹弓':'引力漫游';
  const orbitFeedback=navigationFeedback.update({navigation:navResult,hands:navHands,routes,ownerId:navigation.handId,awaitingOpen:navigation.awaitingOpen,appliedYawDelta:yaw-orbitBeforeYaw,appliedPitchDelta:pitch-orbitBeforePitch,pitch,now,enabled:!paused&&!demo});
  const cameraWaiting=webcamState.active&&!xr&&!navHands.length?(webcamState.inference?.stale?'识别响应较慢 · 旧动作已停，请重新开启摄像头':now-(webcamState.inference?.lastResultAt||webcamState.inference?.startedAt||now)>900?'等待新的手势 · 镜头保持':'将完整手掌放入镜头'):null;
  const cameraResumeHint=webcamState.active&&!xr?calibrationResumeHint(webcamState.calibration):null;
  const restLabel=['resting','returning'].includes(cameraRestResult.phase)?cameraRestResult.label:!navResult.active&&inputNow<cameraRestNoticeUntil?'已恢复控制 · 轻捏继续转角，单指可选站':'';
  const navigationLabel=restLabel||(orbitFeedback?.label?orbitFeedback.label+(cameraResumeHint?' · '+cameraResumeHint:''):cameraResumeHint||castTransition.label||cameraWaiting);
  const actionLabel=demoCast?.awaitTarget?'移到任一奇点附近，重新托举':casting.activeCount?casting.state.label:sling.handle.grabbed?'潮汐已拉开 · 松手发射，丢手只取消':magic.grabbedCount?'已抓住奇点 · 拖动后松手留驻':navigationLabel|| (palmRegrabHint?'已对准奇点 · 拇中指轻捏重新托举':needsOpen?'拇食指仍可转角 · 施法前先张掌':placementArmed?'已选择放置奇点':recoveryEnabled?recoveryHint():resonanceEnabled?(resonanceInstruction?.label||resonance.state.message):slingEnabled?sling.state.message:magic.feedbackActive?magic.state.label:flight.active?'航程已设定 · 拇食指轻捏接管':'拇食指转角 · 拇中指创造 · 张掌托举 · 握拳全爆');
  $('gesture-label').textContent=calibrationBlocked?(webcamState.calibration?.label||'校准中 · 镜头保持'):paused?'时间暂停':demo?'漫游演示 · 点击画面接管':orbitPractice.state.active?(navigationLabel||orbitPractice.state.label)+' · 引导星 '+orbitPractice.state.stars.filter(Boolean).length+' / 3':actionLabel;
 }else{
  const playResumeHint=webcamState.active&&!xr?(webcamState.inputBlocked?webcamState.calibration?.label:calibrationResumeHint(webcamState.calibration)):null;
  $('gesture-label').textContent=paused?'时间暂停':hands.length?(hands.some(h=>h.pinching)?'指尖聚光 · '+(state.held||0)+' 颗':'引力连接 · 挥手改变潮汐')+(playResumeHint?' · '+playResumeHint:''):playResumeHint||(webcamState.active?'将完整手掌放入镜头':'移动指针牵引 · 按住聚光');
  if(!webcamState.active)$('mode-label').textContent=xr?'空间手势':state.running?'夺光挑战':'自由探索';
 }
 if(studio&&!webcamState.active&&!xr&&!demoCast&&!navResult.active&&!paused&&!demo){
  $('gesture-label').textContent='鼠标拖动转角 · 开启摄像头体验掌心操作';
  if(!magic.state.activeCount&&!flight.active&&!recoveryEnabled&&!resonanceEnabled&&!slingEnabled){$('magic-phase').textContent='移动掌心，让引力跟随';$('magic-hint').textContent='主手张掌创造、握拳推进；副手挥动转角、握拳拉远；双拳稍停引爆。鼠标 C 创造、R 托起、F 引爆。';}
 }
 renderPalmControls(palmCamera);
 const info=webcamState.inference||{};
 $('performance').textContent=(renderQuality.fps||'—')+' FPS · '+Math.round(game.count/1000)+'K 粒子'+(webcamState.active?' · 手势 '+Math.round(info.resultHz||0)+' 次/秒 · '+Math.round(info.latencyMs||0)+'ms':'');
 const diagnostics=$('camera-diagnostics');if(diagnostics){diagnostics.hidden=!webcamState.active;diagnostics.textContent='识别 '+(info.backend||info.delegate||info.mode||'准备中')+' · 运算 '+Math.round(info.durationMs||0)+'ms · 画质 '+['精细','平衡','轻量','流畅'][renderQuality.tier]+(info.fallbackReason?' · 已启用兼容模式':'');}
 }
});
document.addEventListener('visibilitychange',()=>{lastTime=0;pointer.inside=false;pointer.down=false;pointer.pendingClick=false;pointer.releaseUntil=0;if(document.hidden){cancelStudioInput();stopFlight();stopDemonstrations();}});
setMode('studio');setDistance(10.2);

// The default soundtrack is optional when browser autoplay needs a gesture.
void initDefaultMusic();
