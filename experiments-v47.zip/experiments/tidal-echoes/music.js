import { AudioFeatures } from './audio-analysis.js';
export const DEFAULT_MUSIC = Object.freeze({ src: './assets/music/shattered-bamboo.mp3', name: '破碎的竹林' });
export const musicState = { session: 0, energy: 0, bass: 0, beat: 0, playing: false, gain: 1, bands: new Float32Array(48), onsets: new Float32Array(48), chroma: new Float32Array(12), note: 0, noteSequence: 0, hitCount: 0, subdivision: 0, subPulse: 0, tempo: 120, tempoReady: false, time: 0, trackKind: null, trackName: '', autoplayBlocked: false };
const $ = id => document.getElementById(id), audio = $('music-audio'), bars = [...document.querySelectorAll('.beat-bars i')];
let context, source, analyser, recordingDestination, frequencies, waveform, url = null, track = null, average = .08, previousEnergy = 0, features = new AudioFeatures();
let loadVersion = 0, playVersion = 0, defaultInitialized = false, waiting = false, needsBaseline = true, lastAudioTime = null, stalledFor = 0;
const clock = () => Number.isFinite(audio.currentTime) ? Math.max(0, audio.currentTime) : 0;
const playable = () => !!analyser && !audio.paused && !audio.ended && !audio.seeking && !audio.error && !waiting && audio.readyState >= 2 && context?.state === 'running';
function ensureAudio() {
  if (context) return;
  const Audio = window.AudioContext || window.webkitAudioContext;
  if (!Audio) throw new Error('当前浏览器不支持音乐分析');
  context = new Audio(); source = context.createMediaElementSource(audio); analyser = context.createAnalyser();
  analyser.fftSize = 2048; analyser.smoothingTimeConstant = .08;
  source.connect(analyser); analyser.connect(context.destination);
  frequencies = new Uint8Array(analyser.frequencyBinCount); waveform = new Uint8Array(analyser.fftSize);
}
function setText(id, text) { const element = $(id); if (element) element.textContent = text; }
function status(text) { setText('music-status', text); }
function showEntry(show) {
  musicState.autoplayBlocked = !!show;
  const button = $('music-enter'); if (button) button.hidden = !show;
}
function clearEnergy() {
  musicState.energy = musicState.bass = musicState.beat = musicState.subPulse = 0;
  musicState.bands.fill(0); musicState.onsets.fill(0); musicState.chroma.fill(0);
  for (const bar of bars) { bar.style.height = '3px'; bar.style.opacity = '.35'; }
}
function suspendAnalysis() {
  musicState.playing = false; clearEnergy(); needsBaseline = true; lastAudioTime = null; stalledFor = 0;
  average = .08; previousEnergy = 0;
}
function resetFeatures(time = 0) {
  musicState.session++; suspendAnalysis(); features = new AudioFeatures();
  musicState.time = time; musicState.note = musicState.noteSequence = musicState.hitCount = musicState.subdivision = 0;
  musicState.tempo = 120; musicState.tempoReady = false;
  setText('music-live', '背景音乐'); setText('hit-counter', '');
}
function selectTrack(kind, src, name, objectURL = null) {
  defaultInitialized = true; loadVersion++; playVersion++; audio.pause();
  if (url) URL.revokeObjectURL(url); url = objectURL; track = { kind, src, name };
  waiting = false; resetFeatures(); audio.loop = kind === 'default'; audio.src = src;
  musicState.trackKind = kind; musicState.trackName = name; showEntry(false);
  $('music-name').textContent = name; $('music-name').title = name; $('music-player').hidden = false;
}
export function resetMusic() {
  defaultInitialized = true; loadVersion++; playVersion++; track = null;
  audio.pause(); audio.removeAttribute('src'); audio.loop = false; audio.load();
  if (url) URL.revokeObjectURL(url); url = null; waiting = false; resetFeatures();
  musicState.trackKind = null; musicState.trackName = ''; showEntry(false);
  $('music-player').hidden = true; $('music-file').value = ''; status('等待一首属于你的音乐');
}

/** Explicit user controls may unlock AudioContext. Startup never waits for an
 * activation promise: a denied autoplay is a visible, single-click entry. */
export async function playMusic({ userGesture = true } = {}) {
  if (!track) return false;
  const version = loadVersion, intent = ++playVersion;
  try {
    ensureAudio();
    if (userGesture && context.state !== 'running') await context.resume();
    if (version !== loadVersion || intent !== playVersion) return false;
    const started = audio.play();
    if (!userGesture && context.state !== 'running') {
      // play() itself may remain pending while the context is suspended.
      // Consume its eventual rejection without making application startup wait.
      audio.pause(); Promise.resolve(started).catch(() => {});
      showEntry(true); status('《' + track.name + '》已就绪 · 点击「进入作品」开启音乐'); return false;
    }
    await started;
    if (version !== loadVersion || intent !== playVersion) return false;
    if (audio.paused || context.state !== 'running') return false;
    showEntry(false); musicState.playing = playable();
    status('背景音乐播放中'); return true;
  } catch (error) {
    if (version !== loadVersion || intent !== playVersion) return false;
    suspendAnalysis(); showEntry(true);
    status(error?.name === 'NotSupportedError' ? '无法解码此音频，请尝试 MP3 或 WAV 格式' : '音乐已就绪 · 点击「进入作品」开启配乐');
    return false;
  }
}
export function loadDefaultMusic({ autoplay = true, userGesture = true } = {}) {
  if (track?.kind !== 'default') selectTrack('default', DEFAULT_MUSIC.src, DEFAULT_MUSIC.name);
  status('默认配乐《' + DEFAULT_MUSIC.name + '》 · 循环播放');
  return autoplay ? playMusic({ userGesture }) : Promise.resolve(false);
}
export function initDefaultMusic() {
  if (defaultInitialized) return Promise.resolve(false);
  return loadDefaultMusic({ autoplay: true, userGesture: false });
}

/** The recorder owns only these clones. Stopping a completed recording never
 * stops the destination's original tracks or the loudspeaker playback path. */
export async function getMusicRecordingStream({ userGesture = false } = {}) {
  if (!track) return null;
  ensureAudio();
  if (userGesture && context.state !== 'running') await context.resume();
  if (!recordingDestination) {
    if (typeof context.createMediaStreamDestination !== 'function') throw new Error('当前浏览器无法录制配乐音轨');
    recordingDestination = context.createMediaStreamDestination(); analyser.connect(recordingDestination);
  }
  if (typeof recordingDestination.stream.clone !== 'function') throw new Error('当前浏览器无法复制录制音轨');
  return recordingDestination.stream.clone();
}
$('music-upload').onclick = () => $('music-file').click(); $('music-clear').onclick = resetMusic;
const enter = $('music-enter'); if (enter) enter.onclick = () => playMusic({ userGesture: true });
const restore = $('music-default'); if (restore) restore.onclick = () => loadDefaultMusic({ autoplay: true, userGesture: true });
$('music-file').onchange = async event => {
  const file = event.target.files[0]; if (!file) return;
  if (!file.type.startsWith('audio/') && !/\.(mp3|wav|ogg|m4a|aac|flac|webm)$/i.test(file.name)) { status('请选择可播放的音频文件'); return; }
  try {
    const localURL = URL.createObjectURL(file); selectTrack('upload', localURL, file.name, localURL);
    status('音乐已导入 · 点击播放背景配乐'); await playMusic({ userGesture: true });
  } catch (error) { suspendAnalysis(); status(error.message || '无法载入音乐，请尝试 MP3 或 WAV'); }
};
audio.addEventListener('seeking', () => { resetFeatures(clock()); });
// Native media controls can unlock sound during their actual pointer/keyboard
// gesture. Programmatic play events cannot request an unbounded resume.
function unlockNativeControls() {
  if (!track) return;
  try { ensureAudio(); if (context.state !== 'running') Promise.resolve(context.resume()).catch(() => { showEntry(true); }); }
  catch { showEntry(true); }
}
audio.addEventListener('pointerdown', unlockNativeControls);
audio.addEventListener('keydown', unlockNativeControls);
audio.addEventListener('play', () => { musicState.playing = playable(); if (musicState.playing) { showEntry(false); status('背景音乐播放中'); } });
audio.addEventListener('playing', () => { waiting = false; if (playable()) showEntry(false); });
for (const event of ['waiting', 'loadstart', 'emptied']) audio.addEventListener(event, () => { waiting = true; suspendAnalysis(); });
audio.addEventListener('pause', () => { playVersion++; suspendAnalysis(); if (track) status('背景音乐已暂停'); });
audio.addEventListener('ended', () => { suspendAnalysis(); status('背景音乐播放结束'); });
audio.addEventListener('error', () => { suspendAnalysis(); if (track) status('无法解码此音频，请尝试 MP3 或 WAV 格式'); });
const analysisGain = $('music-gain');
if (analysisGain) analysisGain.oninput = event => { musicState.gain = +event.target.value; setText('music-gain-value', Math.round(musicState.gain * 100) + '%'); };
export function updateMusic(dt, { analyze = true } = {}) {
  const step = Number.isFinite(dt) ? Math.max(0, Math.min(.1, dt)) : 0, currentTime = clock();
  musicState.time = currentTime;
  // BGM keeps playback and recording alive without reading spectra or emitting
  // visual cues. The scene uses its own neutral input, never this playback state.
  if (!analyze) {
    clearEnergy(); musicState.note = musicState.noteSequence = musicState.hitCount = musicState.subdivision = 0;
    musicState.playing = playable(); needsBaseline = true; lastAudioTime = null; stalledFor = 0;
    return musicState;
  }
  if (!playable()) { suspendAnalysis(); return musicState; }
  // Analyze each audio timestamp only once. Browsers may quantize this clock,
  // so tolerate short repeats while detecting a genuinely stalled stream.
  if (lastAudioTime !== null && currentTime === lastAudioTime) {
    stalledFor += step;
    if (stalledFor >= .25) { musicState.playing = false; clearEnergy(); needsBaseline = true; }
    else { musicState.onsets.forEach((value, index) => { musicState.onsets[index] = value * Math.exp(-step * 20); }); musicState.beat *= Math.exp(-step * 7); musicState.subPulse *= Math.exp(-step * 12); }
    return musicState;
  }
  if (lastAudioTime !== null && (currentTime < lastAudioTime || currentTime - lastAudioTime > .6)) resetFeatures(currentTime);
  lastAudioTime = currentTime; stalledFor = 0; musicState.playing = true;
  analyser.getByteFrequencyData(frequencies); analyser.getByteTimeDomainData(waveform);
  let sum = 0, bass = 0;
  for (let i = 0; i < waveform.length; i++) { const sample = (waveform[i] - 128) / 128; sum += sample * sample; }
  const energy = Math.min(1, Math.sqrt(sum / waveform.length) * 2.2), end = Math.min(frequencies.length - 1, Math.max(2, Math.ceil(230 / (context.sampleRate / analyser.fftSize))));
  for (let i = 1; i <= end; i++) bass += frequencies[i] / 255; bass /= end;
  average += (energy - average) * Math.min(1, step * 2);
  let beat = Math.min(1, Math.max(0, energy - average - .035) * 5 + Math.max(0, energy - previousEnergy) * 3);
  previousEnergy = energy;
  const counts = [features.hitCount, features.noteSequence, features.subdivisionCount];
  const result = features.analyze(frequencies, context.sampleRate, currentTime, step, musicState.gain);
  // A fresh playback window establishes the spectrum, never a synthetic attack
  // caused by loading, scrubbing, returning to a tab or resuming a held note.
  if (needsBaseline) {
    [features.hitCount, features.noteSequence, features.subdivisionCount] = counts;
    [result.hitCount, result.noteSequence, result.subdivision] = counts;
    result.onsets.fill(0); result.subPulse = 0; result.hit = false; beat = 0; average = energy; needsBaseline = false;
  }
  for (let i = 0; i < bars.length; i++) {
    const index = Math.min(frequencies.length - 1, Math.floor(Math.pow(i / Math.max(1, bars.length - 1), 1.8) * 100));
    bars[i].style.height = (3 + frequencies[index] / 255 * 21) + 'px'; bars[i].style.opacity = .35 + frequencies[index] / 255 * .65;
  }
  for (let band = 0; band < 48; band++) {
    musicState.bands[band] += (result.bands[band] - musicState.bands[band]) * (1 - Math.exp(-step * 35));
    musicState.onsets[band] = Math.max(result.onsets[band] * 5, musicState.onsets[band] * Math.exp(-step * 17));
  }
  musicState.chroma.set(result.chroma); musicState.note = result.note; musicState.noteSequence = result.noteSequence;
  musicState.hitCount = result.hitCount; musicState.subdivision = result.subdivision; musicState.subPulse = result.subPulse;
  musicState.tempo = result.tempo; musicState.tempoReady = result.tempoReady; if (result.hit) beat = 1;
  const names = ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B'];
  setText('music-live', (result.tempoReady ? result.tempo + ' BPM 估计' : '节拍学习中') + ' · 音高色彩 ' + names[result.note] + ' · 1/16 细分');
  setText('hit-counter', '瞬态 ' + result.hitCount + ' · 细分 ' + result.subdivision);
  const k = 1 - Math.exp(-step * 10);
  musicState.energy += (energy * musicState.gain - musicState.energy) * k; musicState.bass += (bass * musicState.gain - musicState.bass) * k;
  musicState.beat = Math.max(beat * musicState.gain, musicState.beat * Math.exp(-step * 7));
  return musicState;
}
window.addEventListener('pagehide', () => { loadVersion++; playVersion++; audio.pause(); suspendAnalysis(); if (url) URL.revokeObjectURL(url); context?.close(); });
