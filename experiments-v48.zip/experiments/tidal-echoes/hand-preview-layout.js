const ASPECT = 4 / 3;
const MIN_WIDTH = 128;
const STORAGE_KEY = 'tidal-echoes-hand-preview-width';
const number = (value, fallback = 0) => Number.isFinite(value) ? value : fallback;
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const instances = new WeakMap();

/** CSS pixels only: these dimensions never change camera or landmark buffers. */
export function fitHandPreview(input = {}, bounds = {}) {
  const areaWidth = Math.max(1, number(bounds.width, 1)), areaHeight = Math.max(1, number(bounds.height, 1));
  const margin = Math.min(12, areaWidth / 8, areaHeight / 8);
  const left = number(bounds.left) + margin, top = number(bounds.top) + margin;
  const maxWidth = Math.max(1, Math.min(areaWidth - margin * 2, (areaHeight - margin * 2) * ASPECT));
  const width = clamp(number(input.width, 160), Math.min(MIN_WIDTH, maxWidth), maxWidth), height = width / ASPECT;
  return { width, height, x: clamp(number(input.x, left), left, left + areaWidth - margin * 2 - width),
    y: clamp(number(input.y, top), top, top + areaHeight - margin * 2 - height) };
}

/** Keep the user's size while finding nearby clear space beside UI panels. */
export function placeHandPreview(input, bounds, panels = []) {
  const box = fitHandPreview(input, bounds), gap = 8;
  const overlaps = candidate => panels.some(panel => candidate.x < panel.x + panel.width + gap
    && candidate.x + candidate.width + gap > panel.x && candidate.y < panel.y + panel.height + gap
    && candidate.y + candidate.height + gap > panel.y);
  if (!overlaps(box)) return { ...box, overlap: false };
  const x = [box.x, number(bounds.left), number(bounds.left) + bounds.width - box.width];
  const y = [box.y, number(bounds.top), number(bounds.top) + bounds.height - box.height];
  for (const panel of panels) { x.push(panel.x - box.width - gap, panel.x + panel.width + gap); y.push(panel.y - box.height - gap, panel.y + panel.height + gap); }
  let best = null, score = Infinity;
  for (const left of x) for (const top of y) {
    const candidate = fitHandPreview({ width: box.width, x: left, y: top }, bounds);
    if (overlaps(candidate)) continue;
    const distance = Math.hypot(candidate.x - box.x, candidate.y - box.y);
    if (distance < score) { best = candidate; score = distance; }
  }
  // On very short screens no clear rectangle may exist. Keep the controls
  // accessible at the lower edge; only their hit areas intercept the scene.
  return best ? { ...best, overlap: false } : { ...fitHandPreview({ width: box.width,
    x: number(bounds.left), y: number(bounds.top) + bounds.height - box.height }, bounds), overlap: true };
}

export function initHandPreviewResize({ preview, handle, viewport } = {}) {
  if (!preview || !handle || !viewport) throw new Error('手势预览缩放需要画框、缩放按钮与场景容器。');
  instances.get(preview)?.destroy();
  const doc = preview.ownerDocument, win = doc?.defaultView || globalThis.window;
  const computed = win?.getComputedStyle?.(preview) || {};
  const parsed = value => { const result = parseFloat(value); return Number.isFinite(result) ? result : null; };
  const initialWidth = Math.max(MIN_WIDTH, parsed(computed.width) || 160);
  let preferredWidth = initialWidth, anchor = null, layout = null, drag = null, destroyed = false;
  let storage;
  try { storage = win?.localStorage; const saved = Number(storage?.getItem(STORAGE_KEY)); if (saved >= 96 && saved <= 8192) preferredWidth = saved; } catch {}
  const styleNames = ['--hand-preview-width','--hand-preview-height','--hand-preview-x','--hand-preview-y'];
  const previousStyles = styleNames.map(name => [name, preview.style.getPropertyValue(name), preview.style.getPropertyPriority?.(name) || '']);
  const previousAttribute = preview.getAttribute('data-hand-resizable');
  const previousOverlap = preview.getAttribute('data-hand-overlap');
  const previousHandleLabel = handle.getAttribute('aria-label'), previousHandleTitle = handle.getAttribute('title');
  const previousTabIndex = handle.getAttribute('tabindex');
  const oldClass = preview.classList.contains('hand-preview-resizing');
  const listeners = [];
  const panels = ['#recording-panel','#settings','.topbar'].map(selector => viewport.querySelector?.(selector)).filter(Boolean);
  const listen = (target, type, fn, options) => { target?.addEventListener?.(type, fn, options); listeners.push([target,type,fn,options]); };
  const bounds = () => {
    const r = viewport.getBoundingClientRect();
    const viewWidth = number(win?.visualViewport?.width, number(win?.innerWidth, r.right));
    const viewHeight = number(win?.visualViewport?.height, number(win?.innerHeight, r.bottom));
    const viewLeft = number(win?.visualViewport?.offsetLeft), viewTop = number(win?.visualViewport?.offsetTop);
    const left = Math.max(r.left, viewLeft), top = Math.max(r.top, viewTop);
    return { left: Math.max(0, left - r.left), top: Math.max(0, top - r.top),
      width: Math.max(1, Math.min(r.right, viewLeft + viewWidth) - left),
      height: Math.max(1, Math.min(r.bottom, viewTop + viewHeight) - top), rect: r };
  };
  const persist = () => { try { storage?.setItem(STORAGE_KEY, String(Math.round(preferredWidth * 100) / 100)); } catch {} };
  function refresh() {
    if (destroyed) return layout;
    const area = bounds();
    if (!anchor) {
      const r = preview.getBoundingClientRect();
      const left = parsed(computed.left), right = parsed(computed.right), top = parsed(computed.top), bottom = parsed(computed.bottom);
      anchor = r.width > 0 && r.height > 0
        ? { x: r.left - area.rect.left, y: r.top - area.rect.top }
        : { x: left ?? area.rect.width - (right ?? 24) - preferredWidth,
          y: top ?? area.rect.height - (bottom ?? 100) - preferredWidth / ASPECT };
    }
    const obstacles = panels.filter(panel => !panel.hidden).map(panel => panel.getBoundingClientRect())
      .filter(rect => rect.width > 0 && rect.height > 0).map(rect => ({ x: rect.left - area.rect.left,
        y: rect.top - area.rect.top, width: rect.width, height: rect.height }));
    layout = placeHandPreview({ width: preferredWidth, ...anchor }, area, obstacles);
    if (layout.overlap) preview.setAttribute('data-hand-overlap',''); else preview.removeAttribute('data-hand-overlap');
    for (const [name, value] of [['width',layout.width],['height',layout.height],['x',layout.x],['y',layout.y]]) {
      preview.style.setProperty(`--hand-preview-${name}`, `${value}px`);
    }
    handle.setAttribute('aria-label', `调整手势画框大小，当前 ${Math.round(layout.width)} × ${Math.round(layout.height)}；方向键或加减号调整，Home 恢复`);
    return layout;
  }
  function endDrag({ save = true, revert = false } = {}) {
    if (!drag) return;
    const current = drag; drag = null;
    if (revert) { preferredWidth = current.preferredWidth; anchor = current.anchor; refresh(); }
    preview.classList.toggle('hand-preview-resizing', false);
    try { if (handle.hasPointerCapture?.(current.id)) handle.releasePointerCapture(current.id); } catch {}
    if (save) persist();
  }
  function resize(width) {
    if (destroyed || !Number.isFinite(width)) return layout;
    const current = refresh(); anchor = { x: current.x, y: current.y };
    preferredWidth = clamp(width, 96, 8192); refresh(); persist(); return layout;
  }
  function reset() {
    if (destroyed) return layout;
    endDrag({ save: false }); preferredWidth = initialWidth; refresh(); persist(); return layout;
  }
  function pointerDown(event) {
    if (destroyed || preview.hidden || drag || event.button !== 0 || event.isPrimary === false) return;
    event.preventDefault(); event.stopPropagation();
    const current = refresh();
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY, width: current.width,
      preferredWidth, anchor: { ...anchor } };
    anchor = { x: current.x, y: current.y };
    preview.classList.toggle('hand-preview-resizing', true);
    try { handle.setPointerCapture(event.pointerId); } catch {}
  }
  function pointerMove(event) {
    if (!drag || event.pointerId !== drag.id || destroyed) return;
    event.preventDefault(); event.stopPropagation();
    const dx = event.clientX - drag.x, dy = (event.clientY - drag.y) * ASPECT;
    const delta = Math.abs(dx) >= Math.abs(dy) ? dx : dy;
    preferredWidth = clamp(drag.width + delta, 96, 8192); refresh();
  }
  const pointerEnd = event => { if (drag && event.pointerId === drag.id) { event.stopPropagation?.(); endDrag(); } };
  function keyDown(event) {
    if (event.key === 'Escape' && drag) { event.preventDefault(); event.stopPropagation(); endDrag({ save: false, revert: true }); return; }
    if (event.key === 'Home') { event.preventDefault(); event.stopPropagation(); reset(); return; }
    const direction = ['ArrowRight','ArrowDown','+','='].includes(event.key) ? 1 : ['ArrowLeft','ArrowUp','-','_'].includes(event.key) ? -1 : 0;
    if (direction) { event.preventDefault(); event.stopPropagation(); resize(refresh().width + direction * (event.shiftKey ? 32 : 16)); }
  }
  handle.setAttribute('title','拖动缩放 · 方向键 / 加减号调整 · 双击恢复');
  if (handle.tabIndex < 0) handle.tabIndex = 0;
  listen(handle,'pointerdown',pointerDown);
  // Capture normally keeps moves on the handle. Window listeners also finish
  // the drag safely if a browser declines capture or the pointer exits it.
  listen(win,'pointermove',pointerMove,{passive:false});
  listen(win,'pointerup',pointerEnd); listen(win,'pointercancel',pointerEnd);
  listen(handle,'lostpointercapture',pointerEnd);
  listen(handle,'keydown',keyDown);
  listen(handle,'dblclick',event=>{event.preventDefault();event.stopPropagation();reset();});
  listen(win,'blur',()=>endDrag());
  listen(doc,'visibilitychange',()=>{if(doc.hidden)endDrag();});
  listen(win,'resize',()=>{endDrag();refresh();});
  listen(win?.visualViewport,'resize',refresh); listen(win?.visualViewport,'scroll',refresh);
  const Resize = win?.ResizeObserver || globalThis.ResizeObserver;
  const Mutation = win?.MutationObserver || globalThis.MutationObserver;
  const observer = Resize ? new Resize((entries=[])=>{if(entries.some(entry=>entry.target===viewport))endDrag();refresh();}) : null;
  observer?.observe(viewport);
  for (const panel of panels) observer?.observe(panel);
  const classes = Mutation ? new Mutation(()=>{if(preview.hidden)endDrag();refresh();}) : null;
  if (doc?.body) classes?.observe(doc.body,{attributes:true,attributeFilter:['class']});
  classes?.observe(preview,{attributes:true,attributeFilter:['hidden']});
  for (const panel of panels) classes?.observe(panel,{attributes:true,attributeFilter:['hidden']});
  const restoreAttribute = (element,name,value) => value === null ? element.removeAttribute(name) : element.setAttribute(name,value);
  const api = { resize, reset, refresh,
    get state() { return { ...layout, preferredWidth, resizing: !!drag, destroyed }; },
    destroy() {
      if (destroyed) return; endDrag(); destroyed = true;
      observer?.disconnect(); classes?.disconnect();
      for (const [target,type,fn,options] of listeners) target?.removeEventListener?.(type,fn,options);
      for (const [name,value,priority] of previousStyles) { if(value)preview.style.setProperty(name,value,priority);else preview.style.removeProperty(name); }
      restoreAttribute(preview,'data-hand-resizable',previousAttribute);
      restoreAttribute(preview,'data-hand-overlap',previousOverlap);
      restoreAttribute(handle,'aria-label',previousHandleLabel); restoreAttribute(handle,'title',previousHandleTitle); restoreAttribute(handle,'tabindex',previousTabIndex);
      preview.classList.toggle('hand-preview-resizing',oldClass);
      if (instances.get(preview) === api) instances.delete(preview);
    },
  };
  instances.set(preview,api); refresh(); preview.setAttribute('data-hand-resizable',''); return api;
}
