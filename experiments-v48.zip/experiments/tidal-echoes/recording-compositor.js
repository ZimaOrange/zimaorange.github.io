const FRAME_INTERVAL = 1000 / 30;
const FRAME_EPSILON = .15;

function validRect(rect) {
  return rect && Number.isFinite(rect.left) && Number.isFinite(rect.top)
    && Number.isFinite(rect.width) && Number.isFinite(rect.height) && rect.width > 0 && rect.height > 0;
}

function visible(element) {
  if (!element || element.hidden) return false;
  if (element.getClientRects && !element.getClientRects().length) return false;
  if (element.checkVisibility && !element.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) return false;
  return true;
}

function roundedPanel(context, x, y, width, height) {
  const radius = Math.min(7, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + radius, y);
  context.lineTo(x + width - radius, y);
  context.quadraticCurveTo(x + width, y, x + width, y + radius);
  context.lineTo(x + width, y + height - radius);
  context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  context.lineTo(x + radius, y + height);
  context.quadraticCurveTo(x, y + height, x, y + height - radius);
  context.lineTo(x, y + radius);
  context.quadraticCurveTo(x, y, x + radius, y);
  context.closePath();
}

/** Composes the rendered artwork and its existing skeleton canvas. This module
 * never reads webcam video or owns media tracks. Call draw immediately after the
 * WebGL render, while the artwork drawing buffer is available. The output size
 * is fixed per recording; preview movement/resizing is sampled on each frame. */
export function createRecordingCompositor({ artworkCanvas, handCanvas, previewElement, viewportElement,
  getBadge = () => '', getActive = () => true,
  canvasFactory = () => document.createElement('canvas') } = {}) {
  const canvas = canvasFactory();
  canvas.width = canvas.height = 1;
  let context = null, active = false, lastFrameAt = -Infinity;

  function paint() {
    const width = canvas.width, height = canvas.height;
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.globalAlpha = 1;
    context.globalCompositeOperation = 'source-over';
    context.clearRect(0, 0, width, height);
    context.fillStyle = '#030509';
    context.fillRect(0, 0, width, height);
    context.drawImage(artworkCanvas, 0, 0, width, height);

    if (!getActive() || !visible(previewElement) || !visible(handCanvas)) return;
    if (!(handCanvas.width > 0 && handCanvas.height > 0)) return;
    const viewport = viewportElement?.getBoundingClientRect?.();
    const panel = previewElement.getBoundingClientRect?.();
    if (!validRect(viewport) || !validRect(panel)) return;
    const x = panel.left - viewport.left, y = panel.top - viewport.top;
    if (x >= viewport.width || y >= viewport.height || x + panel.width <= 0 || y + panel.height <= 0) return;

    // CSS object-fit: contain applies inside the canvas element. Its DOM bounds
    // include the current panel size but not its mirrored pixel orientation.
    const bounds = handCanvas.getBoundingClientRect?.();
    const handLeft = validRect(bounds) ? bounds.left - viewport.left : x + 1;
    const handTop = validRect(bounds) ? bounds.top - viewport.top : y + 1;
    const handWidth = validRect(bounds) ? bounds.width : Math.max(1, panel.width - 2);
    const handHeight = validRect(bounds) ? bounds.height : Math.max(1, panel.height - 2);
    const containScale = Math.min(handWidth / handCanvas.width, handHeight / handCanvas.height);
    const drawWidth = handCanvas.width * containScale, drawHeight = handCanvas.height * containScale;
    const drawLeft = handLeft + (handWidth - drawWidth) / 2;
    const drawTop = handTop + (handHeight - drawHeight) / 2;

    context.save();
    try {
      context.scale(width / viewport.width, height / viewport.height);
      roundedPanel(context, x, y, panel.width, panel.height);
      context.fillStyle = 'rgba(8,12,19,.82)';
      context.fill();
      context.strokeStyle = 'rgba(255,255,255,.15)';
      context.lineWidth = 1;
      context.stroke();
      context.clip();
      context.save();
      try {
        context.translate(drawLeft + drawWidth, drawTop);
        context.scale(-1, 1);
        context.drawImage(handCanvas, 0, 0, drawWidth, drawHeight);
      } finally { context.restore(); }
      const badge = String(getBadge() || '').trim();
      if (badge && panel.width > 24 && panel.height > 20) {
        context.fillStyle = '#9baaaa';
        context.font = '8px -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif';
        context.textAlign = 'center';
        context.textBaseline = 'bottom';
        context.fillText(badge, x + panel.width / 2, y + panel.height - 7, panel.width - 16);
      }
    } finally { context.restore(); }
  }

  function stop() {
    active = false;
    lastFrameAt = -Infinity;
    canvas.width = canvas.height = 1;
  }

  return {
    canvas,
    get active() { return active; },
    start({ includeHands = false } = {}) {
      stop();
      if (!includeHands) return canvas;
      if (!(Number.isFinite(artworkCanvas?.width) && Number.isFinite(artworkCanvas?.height)
        && artworkCanvas.width > 0 && artworkCanvas.height > 0)) throw new Error('作品画面尚未准备好，暂时无法录制手势。');
      try {
        canvas.width = artworkCanvas.width;
        canvas.height = artworkCanvas.height;
        context ||= canvas.getContext('2d', { alpha: false });
        if (!context) throw new Error('浏览器暂时无法合成手势画面，请取消勾选后重试。');
        context.imageSmoothingEnabled = true;
        active = true;
        paint();
      } catch (error) { stop(); throw error; }
      return canvas;
    },
    draw(now) {
      if (!active || !Number.isFinite(now)) return false;
      const elapsed = now - lastFrameAt;
      if (elapsed >= 0 && elapsed < FRAME_INTERVAL - FRAME_EPSILON) return false;
      paint();
      // Keep the fractional frame remainder. Reset only for the initial frame,
      // a clock reset or a long pause, so 60 Hz jitter cannot halve the cadence.
      if (!Number.isFinite(lastFrameAt) || elapsed < 0 || elapsed > FRAME_INTERVAL * 4) lastFrameAt = now;
      else lastFrameAt += Math.max(1, Math.floor((elapsed + FRAME_EPSILON) / FRAME_INTERVAL)) * FRAME_INTERVAL;
      return true;
    },
    stop,
  };
}
