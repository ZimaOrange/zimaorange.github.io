const MAX_DURATION_MS = 5 * 60 * 1000;
const MAX_BYTES = 400 * 1024 * 1024;
const VIDEO_BITRATE = 16_000_000;
const AUDIO_BITRATE = 192_000;
const clampLimit = (value, maximum) => Number.isFinite(value) && value > 0 ? Math.min(value, maximum) : maximum;
const tracksOf = stream => stream?.getTracks?.() || [];
const stopTracks = stream => { for (const track of tracksOf(stream)) { try { track.stop(); } catch {} } };
const formatOf = mime => /^video\/mp4(?:;|$)/i.test(mime || '') ? 'mp4'
  : /^video\/webm(?:;|$)/i.test(mime || '') ? 'webm' : null;
const notice = reason => reason === 'size-limit' ? '已达到录制大小上限，视频已收好。'
  : reason === 'time-limit' ? '已达到五分钟上限，视频已收好。'
    : reason === 'background' ? '页面进入后台，已结束录制。'
      : reason === 'capture-ended' ? '画面采集已结束，视频已收好。' : '录制完成，点击下载保存到电脑。';

export function recordingMimeCandidates(hasAudio) {
  const audio = hasAudio ? ',mp4a.40.2' : '';
  return [
    `video/mp4;codecs=avc1.640028${audio}`,
    `video/mp4;codecs=avc1.42E01E${audio}`,
    'video/mp4',
    `video/webm;codecs=vp9${hasAudio ? ',opus' : ''}`,
    `video/webm;codecs=vp8${hasAudio ? ',opus' : ''}`,
    'video/webm',
  ];
}

/** Records the artwork or an optional composed canvas and a dedicated music stream. The audio
 * provider transfers ownership of its cloned tracks; original playback tracks
 * must never be passed here. onBegin/onEnd are synchronous resolution hooks;
 * onBegin may return {canvas} to supply the recording surface for this session.
 * No permission prompt, microphone, screen capture, upload or automatic click. */
export class ArtworkRecorder {
  constructor({ canvas, getAudioStream = () => null, onStateChange = () => {}, onBegin = () => {}, onEnd = () => {},
    maxDurationMs = MAX_DURATION_MS, maxBytes = MAX_BYTES, environment = {} } = {}) {
    this.canvas = canvas; this.getAudioStream = getAudioStream;
    this.onStateChange = onStateChange; this.onBegin = onBegin; this.onEnd = onEnd;
    this.MediaRecorder = environment.MediaRecorder || globalThis.MediaRecorder;
    this.MediaStream = environment.MediaStream || globalThis.MediaStream;
    this.Blob = environment.Blob || globalThis.Blob;
    this.URL = environment.URL || globalThis.URL;
    this.now = environment.now || (() => globalThis.performance?.now?.() ?? Date.now());
    this.setInterval = environment.setInterval || globalThis.setInterval.bind(globalThis);
    this.clearInterval = environment.clearInterval || globalThis.clearInterval.bind(globalThis);
    this.setTimeout = environment.setTimeout || globalThis.setTimeout.bind(globalThis);
    this.clearTimeout = environment.clearTimeout || globalThis.clearTimeout.bind(globalThis);
    this.eventTarget = environment.eventTarget ?? globalThis.window;
    this.maxDurationMs = clampLimit(maxDurationMs, MAX_DURATION_MS); this.maxBytes = clampLimit(maxBytes, MAX_BYTES);
    this.softBytes = this.maxBytes - Math.min(8 * 1024 * 1024, this.maxBytes * .1);
    this.session = null; this.disposed = false;
    const supported = typeof canvas?.captureStream === 'function' && typeof this.MediaRecorder === 'function'
      && typeof this.MediaStream === 'function';
    this.state = { phase: supported ? 'idle' : 'unsupported', supported, elapsedMs: 0, bytes: 0,
      hasAudio: false, includeHands: false, mimeType: '', result: null, reason: null,
      message: supported ? '直接录制作品画面，可同时收录已导入的音乐。' : '当前浏览器不支持作品录制，请使用支持 MediaRecorder 的桌面浏览器。' };
    this.pagehide = () => this.dispose();
    this.eventTarget?.addEventListener?.('pagehide', this.pagehide);
  }

  publish(extra) {
    this.state = { ...this.state, ...extra };
    try { this.onStateChange(this.state); } catch { /* UI failure cannot leak capture tracks. */ }
    return this.state;
  }

  clearResult() {
    const result = this.state.result;
    if (result?.url) { try { this.URL.revokeObjectURL(result.url); } catch {} }
    if (result) this.publish({ result: null, ...(this.state.phase === 'ready' ? { phase: 'idle', message: '已清除上次录制，可开始新的片段。' } : {}) });
  }

  async start({ includeHands = false } = {}) {
    if (this.disposed || this.session || !this.state.supported) return false;
    this.clearResult();
    if (this.disposed || this.session) return false;
    const session = { recorder: null, tracks: new Set(), chunks: [], bytes: 0, chunkMime: '', includeHands: !!includeHands,
      startedAt: null, began: false, ended: false, finished: false, reason: 'user',
      interval: null, stopTimeout: null, trackListeners: [], abort: new AbortController() };
    session.done = new Promise(resolve => { session.resolve = resolve; });
    this.session = session;
    this.publish({ phase: 'starting', elapsedMs: 0, bytes: 0, hasAudio: false, includeHands: session.includeHands, mimeType: '', reason: null, message: '正在准备录制…' });
    try {
      if (session.finished) return false;
      session.began = true;
      const surface = this.onBegin({ signal: session.abort.signal, includeHands: session.includeHands });
      if (session.finished) return false;
      const captureCanvas = surface?.canvas || this.canvas;
      if (typeof captureCanvas?.captureStream !== 'function') throw new Error('无法采集这次选择的录制画面。');
      session.width = captureCanvas.width; session.height = captureCanvas.height;
      const video = captureCanvas.captureStream(30);
      for (const track of tracksOf(video)) session.tracks.add(track);
      const videoTracks = video?.getVideoTracks?.().filter(track => track.readyState !== 'ended') || [];
      if (!videoTracks.length) throw new Error('无法采集作品画面，请稍后重试。');
      const audio = await this.getAudioStream({ signal: session.abort.signal });
      // An AudioContext resume or other provider may resolve after cancellation.
      // Its dedicated clones are disposed without reviving the cancelled run.
      if (session.finished || this.session !== session || this.disposed) { stopTracks(audio); return false; }
      for (const track of tracksOf(audio)) session.tracks.add(track);
      const audioTracks = audio?.getAudioTracks?.().filter(track => track.readyState !== 'ended') || [];
      session.hasAudio = audioTracks.length > 0;
      const stream = new this.MediaStream([...videoTracks, ...audioTracks]);
      let lastError;
      const candidates = recordingMimeCandidates(session.hasAudio).filter(mime => {
        try { return typeof this.MediaRecorder.isTypeSupported !== 'function' || this.MediaRecorder.isTypeSupported(mime); }
        catch { return false; }
      });
      // Default selection is a final fallback; its actual recorder/chunk MIME
      // still determines the extension, never a guessed .mp4 filename.
      for (const mime of [...candidates, '']) {
        let recorder;
        try {
          recorder = new this.MediaRecorder(stream, { ...(mime ? { mimeType: mime } : {}),
            videoBitsPerSecond: VIDEO_BITRATE, ...(session.hasAudio ? { audioBitsPerSecond: AUDIO_BITRATE } : {}) });
          session.recorder = recorder; session.requestedMime = mime;
          recorder.ondataavailable = event => this.data(session, event.data);
          recorder.onerror = event => this.fail(session, event.error || new Error('浏览器无法继续编码这段视频。'));
          recorder.onstop = () => this.complete(session);
          recorder.start(1000);
          break;
        } catch (error) {
          lastError = error;
          if (recorder) {
            recorder.ondataavailable = recorder.onerror = recorder.onstop = null;
            try { if (recorder.state !== 'inactive') recorder.stop(); } catch {}
          }
          session.recorder = null;
        }
      }
      if (session.finished) return false;
      if (!session.recorder) throw lastError || new Error('当前浏览器没有可用的视频编码格式。');
      session.startedAt = this.now();
      session.bitrate = (session.recorder.videoBitsPerSecond || VIDEO_BITRATE)
        + (session.hasAudio ? session.recorder.audioBitsPerSecond || AUDIO_BITRATE : 0);
      for (const track of videoTracks) {
        const ended = () => this.stop('capture-ended');
        track.addEventListener?.('ended', ended); session.trackListeners.push([track, ended]);
      }
      session.interval = this.setInterval(() => this.tick(session), 500);
      this.publish({ phase: 'recording', hasAudio: session.hasAudio, mimeType: session.recorder.mimeType || session.requestedMime,
        message: session.hasAudio ? '正在录制作品与音乐。' : '正在录制作品画面。' });
      return !session.finished && this.state.phase === 'recording';
    } catch (error) {
      if (!session.finished) this.fail(session, error);
      return false;
    }
  }

  tick(session) {
    if (session.finished || this.session !== session || this.state.phase !== 'recording') return;
    const elapsedMs = Math.max(0, this.now() - session.startedAt);
    this.publish({ elapsedMs, bytes: session.bytes });
    if (session.finished || this.session !== session || this.state.phase !== 'recording') return;
    if (elapsedMs >= this.maxDurationMs) this.stop('time-limit');
    else if (session.bytes >= this.softBytes || elapsedMs / 1000 * session.bitrate / 8 >= this.softBytes) this.stop('size-limit');
  }

  data(session, blob) {
    if (session.finished || this.session !== session || !blob || !Number.isFinite(blob.size) || blob.size <= 0) return;
    // Timeslices can be delayed by browsers. Reserve room for the final chunk,
    // and reject an unexpectedly oversized result instead of retaining it or
    // offering a silently truncated, unplayable download.
    if (session.bytes + blob.size > this.maxBytes) {
      this.fail(session, new Error('录制数据超出内存上限，请缩短片段后重试。')); return;
    }
    session.chunks.push(blob); session.bytes += blob.size;
    if (formatOf(blob.type)) session.chunkMime = blob.type;
    this.publish({ bytes: session.bytes });
    if (!session.finished && this.session === session && this.state.phase === 'recording' && session.bytes >= this.softBytes) this.stop('size-limit');
  }

  stop(reason = 'user') {
    const session = this.session;
    if (!session) return Promise.resolve(this.state.result);
    if (this.state.phase === 'starting') { this.cancel(reason); return session.done; }
    if (this.state.phase === 'stopping') return session.done;
    session.reason = reason;
    this.publish({ phase: 'stopping', reason, elapsedMs: Math.max(0, this.now() - session.startedAt), message: '正在收好视频…' });
    if (session.finished || this.session !== session) return session.done;
    session.stopTimeout = this.setTimeout(() => this.fail(session, new Error('浏览器未能完成录制，请重试较短片段。')), 5000);
    try { if (session.recorder.state !== 'inactive') session.recorder.stop(); }
    catch (error) { this.fail(session, error); }
    return session.done;
  }

  complete(session) {
    if (session.finished || this.session !== session) return;
    try {
      if (!session.bytes) throw new Error('这次没有收到视频画面，请稍候重试。');
      const recorderMime = session.recorder?.mimeType || '';
      const mimeType = formatOf(recorderMime) ? recorderMime : session.chunkMime || session.requestedMime;
      const extension = formatOf(mimeType);
      if (!extension) throw new Error('浏览器返回了无法确认的视频格式，未生成下载文件。');
      const blob = new this.Blob(session.chunks, { type: mimeType });
      const stamp = new Date().toISOString().slice(0, 19).replace(/[-:]/g, '').replace('T', '-');
      const result = { blob, url: this.URL.createObjectURL(blob), mimeType, extension,
        filename: `tidal-echoes-${stamp}.${extension}`, durationMs: Math.max(0, this.now() - session.startedAt),
        hasAudio: session.hasAudio, includeHands: session.includeHands, width: session.width, height: session.height, bytes: blob.size };
      this.finish(session, { phase: 'ready', result, message: notice(session.reason), reason: session.reason });
    } catch (error) { this.fail(session, error); }
  }

  fail(session, error) {
    if (session.finished) return;
    this.finish(session, { phase: 'error', result: null, reason: 'error', error,
      message: error?.message || '录制失败，请稍后重试。' });
  }

  finish(session, { phase, result = null, reason, message, error = null }) {
    if (session.finished) return;
    session.finished = true; session.abort.abort();
    if (session.interval !== null) this.clearInterval(session.interval);
    if (session.stopTimeout !== null) this.clearTimeout(session.stopTimeout);
    for (const [track, listener] of session.trackListeners) track.removeEventListener?.('ended', listener);
    const recorder = session.recorder;
    if (recorder) {
      recorder.ondataavailable = recorder.onerror = recorder.onstop = null;
      try { if (recorder.state !== 'inactive') recorder.stop(); } catch {}
    }
    for (const track of session.tracks) { try { track.stop(); } catch {} }
    session.tracks.clear(); session.chunks = [];
    if (session.began && !session.ended) {
      session.ended = true;
      try { this.onEnd({ reason, result, error }); }
      catch { message += ' 录制已结束，但画质恢复需要刷新页面。'; }
    }
    if (this.session === session) {
      this.session = null;
      this.publish({ phase, result, reason, message, bytes: result?.bytes || 0,
        elapsedMs: result?.durationMs || 0, ...(result ? { mimeType: result.mimeType, hasAudio: result.hasAudio } : {}) });
    }
    session.resolve(result);
  }

  cancel(reason = 'cancelled') {
    const session = this.session;
    if (session) this.finish(session, { phase: 'idle', reason, message: '录制已取消。' });
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true; this.cancel('pagehide'); this.clearResult();
    this.eventTarget?.removeEventListener?.('pagehide', this.pagehide);
    this.publish({ phase: 'disposed', message: '录制资源已释放。' });
  }
}

export const createArtworkRecorder = options => new ArtworkRecorder(options);
